<%@ page contentType="text/html; charset=UTF-8"%>

/*
 * [Enter]押下時に画面内の最初のbuttonかsubmitの処理を実行する。
 *
 */
function checkEnter() {
    // Enter
    if (event.keyCode == 13){
        if (event.srcElement.type == 'button'
            || event.srcElement.type == 'reset'
            || event.srcElement.type == 'submit') {
            return true;
        }
        for (i=0; i < document.forms[0].elements.length; i++){

            if (document.forms[0].elements[i].type == 'button'
                || document.forms[0].elements[i].type == 'submit') {

				document.forms[0].elements[i].focus();
                document.forms[0].elements[i].click();

				event.returnValue=false;
                return true;
            }
        }
    }
    return true;
}
/*
 * 入力項目内以外で[Backspace]押下時にBackspace処理を実行させない。
 *
 */
function checkBackspace(){
	//BackSpace
    if (event.keyCode == 8){

		if(event.srcElement.type == 'text' || event.srcElement.type == 'textArea'){

		    if(!event.srcElement.disabled && !event.srcElement.getAttribute('readOnly')){
    		    return true;
    		}
    	}

    	return false;
    }

    return true;
}
/*
 * [Esc]押下時に処理を実行させない。
 *
 */
function checkEsc(){
	//Esc
    if (event.keyCode == 27){

    	return false;
    }

    return true;
}
/*
 * onkeydownイベント時にcheckEnter()、checkEsc()、checkBackspace()処理を実行する。
 *
 */
window.document.onkeydown= function(){
	var flg=checkEnter() && checkEsc() && checkBackspace();
	return flg;
}
