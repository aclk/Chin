<%@ page contentType="text/html; charset=UTF-8"%>

var befor = "";

/*
 * 入力項目にてキー入力前の値をbefor変数に設定する。
 * onkeydownイベント時に呼び出される。
 */
function beforValue(input) {
  befor = input.value;
}

/*
 * 入力項目にてmaxlength数以上入力すると、次の入力項目へフォーカスを移動させる。
 * onkeyupイベント時に呼び出される。
 */
function autoTab(input, e) {
  var keyCode = e.keyCode;
  var filter;
  if(e.altKey){
    filter = [0,8,9,13,16,17,18,19,20,25,28,29,37,38,39,40,44,45,46,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,145,240,243,244,255];
  }else{
    filter = [0,8,9,13,16,17,18,19,20,25,28,29,37,38,39,40,44,45,46,91,145,240,243,244,255];
  }
  var len = input.maxLength;
  if(!isAutoFocusable(input)){
    var index = (getIndex(input) + 1) % input.form.length;
    if(!isAutoFocusable(input.form[index])){
      autoTab(input.form[index], e);
    } else {
      input.form[index].focus();
    }
  }else if (input.value.length >= len && !containsElement(filter, keyCode)) {
    if (input.value.charAt(input.value.length - 1) != befor.charAt(input.value.length - 1)) {
      var index = (getIndex(input) + 1) % input.form.length;
      if(!isAutoFocusable(input.form[index])){
        autoTab(input.form[index], e);
      } else {
        input.form[index].focus();
      }
    }
  }

  function containsElement(arr, ele) {
    var found = false, index = 0;
    while(!found && index < arr.length)
    if(arr[index] == ele)
      found = true;
    else
      index++;
    return found;
  }

  function getIndex(input) {
    var index = -1, i = 0, found = false;
    while (i < input.form.length && index == -1)
    if (input.form[i] == input)index = i;
    else i++;
    return index;
  }
  return true;

/*
 * 指定のelementがフォーカス移動対象であるかチェックする
 * autoTab用の関数
 */
  function isAutoFocusable(element){
    //フォーカス移動不可項目を追加してください
    if (element.type == 'hidden') {
      return false;
    //ラジオボタンの場合選択状態のみフォーカス対象とする
    }else if(element.type == 'radio'){
      if(!element.checked){
        return false;
      }
    }
    else if( element.disabled){
      return false;
    }
    else if(element.getAttribute('readOnly')){
      return false;
    }
    return true;
  }
}
