<%@ page contentType="text/html; charset=UTF-8"%>

<%@ page import="java.util.List" %>
<%@ page import="murata.co.util.constants.CommonConstants" %>

<%
List errorFieldsList = (List)request.getAttribute(CommonConstants.ERROR_FIELDS);
String errorFields = "";
if (errorFieldsList != null) {
  for (int i=0; i<errorFieldsList.size(); i++) {
    if (errorFields != "") errorFields = errorFields + ",";
    errorFields = errorFields + errorFieldsList.get(i);
  }
}
%>

/*
 * エラー入力された項目にエラー入力項目用のスタイルシートを適用する。
 * onLoadイベント時に呼び出される。
 */
function errorFields(form) {
    if(form == null){
        form = document.forms[0];
    }

    if(form){
      var errorFields = "<%= errorFields %>".split(",");
      for (i in errorFields) {
          var field = errorFields[i];
          var obj = form.elements[field];
          if(obj){
              var type = obj.type;
              if(type=="text" || type=="textarea"|| type=="checkbox"){
                      obj.className = "err_input";
              }
          }
      }
    }
}


/*
 * エラー表示されている入力項目にフォーカスが当たった場合、
 * エラーフォーカス用のスタイルシートを適用し
 * 正常表示されている入力項目にフォーカスが当たった場合、
 * 指定されたスタイルシートを適用する。
 * onfocusイベント時に呼び出される。　
 */
function onfocusStyle(obj, style) {

  var errorFields = "<%= errorFields %>".split(",");
  for (i in errorFields) {
    var field = errorFields[i];

    if (obj.name == field) {
      obj.className = 'err_focus';
      obj.select();
      return;
    }
  }

  obj.className = style;
  obj.select();

}

/*
 * エラー表示されている入力項目からフォーカスが離れた場合、
 * エラー入力項目用のスタイルシートを適用し
 * 正常表示されている入力項目からフォーカスが離れた場合、
 * 指定されたスタイルシートを適用する。
 * onblurイベント時に呼び出される。　
 */
function onblurStyle(obj, style) {

  var errorFields = "<%= errorFields %>".split(",");
  for (i in errorFields) {
    var field = errorFields[i];

    if (obj.name == field) {
      obj.className='err_input';
      return;
    }
  }
  obj.className = style;
}

function disableButtons() {
	<%
		Boolean disable = (Boolean)request.getAttribute("button.disable");
		if (disable != null && disable == true) {
	%>
		if (document.forms[0].elements["_regist_"] != null) {
	 		document.forms[0]._regist_[0].disabled = true;
	 		document.forms[0]._regist_[1].disabled = true;
	 	}
		if (document.forms[0].elements["_prev_"] != null) {
	 		document.forms[0]._prev_[0].disabled = true;
	 		document.forms[0]._prev_[1].disabled = true;
	 	}
		if (document.forms[0].elements["_next_"] != null) {
	 		document.forms[0]._next_[0].disabled = true;
	 		document.forms[0]._next_[1].disabled = true;
	 	}
		if (document.forms[0].elements["_reset_"] != null) {
	 		document.forms[0]._reset_[0].disabled = true;
	 		document.forms[0]._reset_[1].disabled = true;
	 	}
 	<%}%>
}