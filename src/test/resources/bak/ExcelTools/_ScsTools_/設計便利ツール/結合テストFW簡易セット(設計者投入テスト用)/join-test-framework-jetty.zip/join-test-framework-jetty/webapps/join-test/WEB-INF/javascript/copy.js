<%@ page contentType="text/html; charset=UTF-8"%>

/*
 * 画面表示内容をクリップボードにコピーする。
 * コピーボタン押下時に実行される関数。
 */
function copyview()
{
    var elements = document.forms[0];
    var esize;
    for( i=0; i<elements.length; i++ )
    {
        if ( elements[i].type == 'text' )
        {
            elements[i].style.display = 'none';
            var v = elements[i].value;
            esize = elements[i].size;
            if ( esize > 0 )
            {
                while(v.length<esize)
                {
                    if (elements[i].style.textAlign=='right')
                        v = " " + v;
                    else
                        v = v + " ";
                }
            }

            spanObj=document.createElement('SPAN');
            spanObj.setAttribute('id', "dummy" + i);
            preObj=document.createElement('PRE');
            preObj.innerText=v;
            spanObj.appendChild(preObj);
            elements[i].parentNode.insertBefore(spanObj, elements[i]);
        }
    }
    var spans = document.all.tags( 'SPAN' );
    // id が hidebr, hidehr のものは HTMLを一時削除
    for( i=0; i<spans.length-1; i++ )
    {
        if ( spans[i].id == 'hidebr' || spans[i].id == 'hidehr' )
        {
            spans[i].innerHTML = '';
        }
    }
    window.top.main.focus();
    document.body.createTextRange().execCommand("Copy");

    var spans = document.all.tags( 'SPAN' );
    for( i=spans.length-1; i>=0; i-- )
    {
        if ( spans[i].id.indexOf( 'dummy', 0 ) == 0 )
        {
            spans[i].parentNode.removeChild(spans[i]);
        // id が hidebr の HTMLを復活
        } else if ( spans[i].id == 'hidebr' )
        {
            spans[i].innerHTML = '<br>';
        // id が hidehr の HTMLを復活
        } else if ( spans[i].id == 'hidehr' )
        {
            spans[i].innerHTML = '<hr>';
        }
    }

    var elements = document.forms[0];
    for( i=0; i<elements.length; i++ )
    {
        if ( elements[i].type == 'text' )
        {
              elements[i].style.display = '';
        }
    }

    tagFocus();
    alert("コピー終了しました。");
}