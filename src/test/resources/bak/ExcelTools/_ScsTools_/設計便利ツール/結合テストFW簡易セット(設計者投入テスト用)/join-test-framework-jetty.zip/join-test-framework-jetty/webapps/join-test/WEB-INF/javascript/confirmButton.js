<%@ page contentType="text/html; charset=UTF-8"%>

var confirmFlag = true;

/*
 * 確認ダイアログを表示しないで処理を継続する
 * 二重サブミット時はfalseが戻される。
 * ボタンのonclickイベント時に呼び出される。
 */
function submitNoConfirm(button) {
    if(confirmFlag==false){
        return false;
    }
    confirmFlag = false;
    return true;
}
/*
 * 指定されたメッセージの確認ダイアログを表示させる。
 *メッセージの指定がない場合はリソース定義のメッセージ（confirm.message.done）を表示させる。
 * ボタンのonclickイベント時に呼び出される。
 */
function submitConfirm(button,message) {
    if(confirmFlag==false){
        return false;
    }
    var msg = "";
    if(message != null){
        msg = message;
    }
    else{
        msg = "<bean:message key="confirm.message.done"/>";
        if(button != null){
            label = button.value;
            if(label != null && label != ""){
                /*
                 * 引数値からアクセスキー表示( (G)、(E)...）を取り除く。
                 * アクセスキーの判定は「正規表現に合致する引数値の最後３文字」です。
                 */
                function removeAccessKey(value) {
                    re = new RegExp(/\([A-Z]{1}\)/);
                    if( 3<value.length && value.substr(value.length-3).match(re)) {
                        return value.substr(0, value.length-3);
                    } else {
                        return value;
                    }
                }
                /*
                 * 引数値からスペース（半角、全角）を取り除く。
                 */
                function removeSpace(value) {
                    return value.replace(/[　 ]*/g, "");
                }

                msg = removeSpace(removeAccessKey(label)) + "<bean:message key="confirm.message"/>";
            }
        }
    }
    if(confirm(msg)){
        confirmFlag = false;
        return true;
    }
    return false;
}
