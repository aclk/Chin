set linesize 40
set verify off
set feed off
set pause off
set heading off
set termout off
set pagesize 0
set echo off
spool all_truncate.sql
select 'truncate table ' || table_name || ';' from user_tables order by table_name;
spool off
quit;
