package p;

import murata.co.application.Executable;

/**
 */
public interface Trial extends Executable {

}
