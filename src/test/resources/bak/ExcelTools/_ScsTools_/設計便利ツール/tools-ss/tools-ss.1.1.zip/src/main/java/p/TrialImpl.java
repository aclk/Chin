package p;

import static murata.co.Constants.VALUE_HANKAKU_SPACE;

import java.text.SimpleDateFormat;
import java.util.Date;

import murata.co.application.BasePGM;
import murata.co.application.Result;
import murata.co.component.dac.DAC;
import murata.co.info.CommonInfo;
import murata.co.util.CacheManager;
import murata.co.vo.BatchCommonVO;
import murata.dbm.bmc.dbmpartnameintegrationbmc.DbmPartNameIntegrationBMC;
import murata.dbm.bmc.dbmpartnameintegrationbmc.vo.GetInternalUsePartNameCodeForCompositionPartNameInputVO;
import murata.dbm.bmc.dbmpartnameintegrationbmc.vo.GetInternalUsePartNameCodeForCompositionPartNameOutputVO;
import murata.dbm.bmc.dbmpartnumberbmc.DbmPartNumberBMC;
import murata.dbm.bmc.dbmpricebmc.DbmPriceBMC;
import murata.dbm.bmc.dbmpricebmc.vo.CalculateDealingPriceInputVO;
import murata.dbm.bmc.dbmpricebmc.vo.CalculateDealingPriceOutputVO;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.access.SingletonBeanFactoryLocator;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Transactional;

/**
 * ���C�y��BMC�Ȃǂ𓮂����Ă݂����l�̂��߂̃g���C�A��
 * Build-jcl����N������΁A���̃N���X��execute()���\�b�h���Ăяo���܂��B
 *
 * @since JDK5.0
 */
public class TrialImpl<ENTITY> extends BasePGM {
    /** ���K. */
    private static Log log = LogFactory.getLog(TrialImpl.class);

    /** DAC�擾. */
    private DAC<ENTITY> getDac(Class<ENTITY> clazz) {
        return (DAC<ENTITY>)getDac();
    }

    /** DAC�擾 */
    private DAC getDac() {
        ApplicationContext context =
            (ApplicationContext)SingletonBeanFactoryLocator.getInstance(
                "springconf/testBeanRefContext.xml").useBeanFactory("context")
                .getFactory();
        return (DAC)context.getBean("jdbcDac");

    }

    /** ���ʏ����������܂��B */
    private void prepareCommonInfo() {
        // CommonInfo�̐ݒ�
        CommonInfo commonInfo =
            (CommonInfo) CacheManager.get(CacheManager.Key.COMMON_INFO);
        if (commonInfo == null) {
            commonInfo = new CommonInfo();
            CacheManager.set(CacheManager.Key.COMMON_INFO, commonInfo);
        }
        commonInfo.setOnline(true);
    }


    /**
     * build-jcl������{����郁�C�����\�b�h.
     */
    @Transactional(readOnly = false)
    public Result execute(BatchCommonVO vo) {
        prepareCommonInfo();
        try {
            /* �f�[�^�̓������s���ꍇ�̓R�����g���O��*/
//            CriteriaEvidenceCreatorAdaptor.restore();
//            */
            // ���������R�ɕύX
            getDac().fill(new murata.ss.entity.FPDiscrepancy());
            trial1();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new Result();
    }


    /**
     * ������i�Z�o���Ă݂�
     * @throws Exception
     */
    void trial1() throws Exception {
        String cd00167 = "84JBF";
        String cd00163 = "HIN9999";
        String cd00120 = "TOKUI";
        String productionAffiliateCode = "MME";
        Long sumOrderQuantity = 10L;
        String dealingDistinctionCodeForPrice = "0";
        String scCode = VALUE_HANKAKU_SPACE;
        String divisionCode = VALUE_HANKAKU_SPACE;

        //������i�����o�� ��FD_SOB0010:DOC2.0 2
        CalculateDealingPriceInputVO calculateDealingPriceInputVO =
            new CalculateDealingPriceInputVO();
        //�i�핪�ރR�[�h(H)
        calculateDealingPriceInputVO.setProductClassificationCodeH50(cd00167);
        //���c�i�ԃR�[�h
        calculateDealingPriceInputVO.setMurataPartNumberCode(cd00163);
        //���Ӑ�R�[�h
        calculateDealingPriceInputVO.setCustomerCode(cd00120);
        //�������_�R�[�h
        calculateDealingPriceInputVO
            .setProductionAffiliateCode(productionAffiliateCode);
        //�w�ߍ��v
        calculateDealingPriceInputVO.setQuantity(sumOrderQuantity);
        //���i�p������ʃR�[�h
        calculateDealingPriceInputVO
            .setDealingDistinctionCodeForPrice(dealingDistinctionCodeForPrice);
        //SC�R�[�h
        calculateDealingPriceInputVO.setScCode(scCode);
        //DIVISION�R�[�h
        calculateDealingPriceInputVO.setDivisionCode(divisionCode);
        //���i�Z�o���
        calculateDealingPriceInputVO.setDateOfStandardForCalculatePrice(null);
        //DBM���iBMC.������i()
        CalculateDealingPriceOutputVO calculateDealingPriceOutputVO =
            dbmPriceBMC.calculateDealingPrice(calculateDealingPriceInputVO);

        log.debug("resultCode:"
            + calculateDealingPriceOutputVO.getCheckResultCode());
        log.debug("price:" + calculateDealingPriceOutputVO.getDealingPrice());
    }

    /**
     * �����Ǘ��i��(�����i���Ή���)���Ăяo���Ă݂�
     */
    void trial2() throws Exception {

        String compositionPartName = "MPF3623/999";
        String packageCode = "999";
        String factoryCode = "11";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        Date dop = sdf.parse("2008/02/08");

        GetInternalUsePartNameCodeForCompositionPartNameInputVO getInternalUsePartNameCodeForCompositionPartNameInputVO =
            new GetInternalUsePartNameCodeForCompositionPartNameInputVO();
        //���c�i�ԃR�[�h
        getInternalUsePartNameCodeForCompositionPartNameInputVO
            .setCompositionPartName(compositionPartName);
        //��R�[�h
        getInternalUsePartNameCodeForCompositionPartNameInputVO
            .setPackageCode(packageCode);
        //�n�t�s�h�m�w�ߌ�����敪�R�[�h
        getInternalUsePartNameCodeForCompositionPartNameInputVO
            .setFactoryCode(factoryCode);
        //������
        getInternalUsePartNameCodeForCompositionPartNameInputVO
            .setDeterminationDate(dop);
        // DBM�i������BMC.�����Ǘ��i���擾(�����i���Ή���)
        GetInternalUsePartNameCodeForCompositionPartNameOutputVO getInternalUsePartNameCodeForCompositionPartNameOutputVO =
            dbmPartNameIntegrationBMC
                .getInternalUsePartNameCodeForCompositionPartName(getInternalUsePartNameCodeForCompositionPartNameInputVO);
        log.debug("�������ʃR�[�h=["
            + getInternalUsePartNameCodeForCompositionPartNameOutputVO
                .getCheckResultCode() + "]");
        log.debug("�����Ǘ��i���R�[�h=["
            + getInternalUsePartNameCodeForCompositionPartNameOutputVO
                .getInternalUsePartNameCode() + "]");
        log.debug("�����Ǘ���R�[�h=["
            + getInternalUsePartNameCodeForCompositionPartNameOutputVO
                .getInternalUsePackageCode() + "]");
    }



    //==================================================================================
    private DbmPartNameIntegrationBMC dbmPartNameIntegrationBMC;

    private DbmPartNumberBMC dbmPartNumberBMC;

    private DbmPriceBMC dbmPriceBMC;

    /**
     * dbmpartnameintegrationbmc�ݒ�B
     * @param dbmpartnameintegrationbmc the dbmpartnameintegrationbmc to set
     */
    public void setDbmPartNameIntegrationBMC(
        DbmPartNameIntegrationBMC dbmpartnameintegrationbmc) {
        this.dbmPartNameIntegrationBMC = dbmpartnameintegrationbmc;
    }

    /**
     * dbmPartNumberBMC�ݒ�B
     * @param dbmPartNumberBMC the dbmPartNumberBMC to set
     */
    public void setDbmPartNumberBMC(DbmPartNumberBMC dbmPartNumberBMC) {
        this.dbmPartNumberBMC = dbmPartNumberBMC;
    }

    /**
     * dbmPriceBMC�ݒ�B
     * @param dbmPriceBMC the dbmPriceBMC to set
     */
    public void setDbmPriceBMC(DbmPriceBMC dbmPriceBMC) {
        this.dbmPriceBMC = dbmPriceBMC;
    }

}
