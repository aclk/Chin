<%@ page contentType="text/html; charset=UTF-8"%>

/*
 * 一覧部のINPUT項目に対し変更が行われたかどうかを判断する。
 * onchangeイベント時に呼び出される。
 */
function changeFlg(input){
  //一覧部の同一行のchangedフラグがtrueの場合は未処理
  if (document.getElementsByName(input.name.substring(0,input.name.indexOf(']')+1) +'.changed')[0].value=='true') {
    return;
  }

  //changedフラグにtrueを設定する
  document.getElementsByName(input.name.substring(0,input.name.indexOf(']')+1) +'.changed')[0].value=true;

}