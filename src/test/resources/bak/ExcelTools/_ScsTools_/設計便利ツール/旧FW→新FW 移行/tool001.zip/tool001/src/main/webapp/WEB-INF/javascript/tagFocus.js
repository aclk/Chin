<%@ page contentType="text/html; charset=UTF-8"%>

<%@ page import="murata.co.Constants" %>
<%
String fieldArrayString = (String)request.getAttribute(Constants.CURSOR_FIELD);
%>

/*
 * 画面内の先頭のフォーカス可能な項目にフォーカスをあてる。
 * onLoadイベント時に呼び出される。
 */
function tagFocus(form) {
    if(form == null){
        form = document.forms[0];
    }

    var fieldArrayString = "<%= fieldArrayString %>";
    if(form){
        var obj = form.elements[fieldArrayString];
        if(obj){
            var type = obj.type;
            if(type=="text" || type=="textarea"){
                obj.select();
            }
        } else {
            for (i=0; i < form.length; i++) {
                if (form.elements[i].type == 'text' ||
                    form.elements[i].type == 'radio' ) {
                    if(isFocusable(form.elements[i])){
                        form.elements[i].select();
                        break;
                    }
                }
            }
        }
    }
}
/*
 * 画面内のreadOnlyの項目をフォーカス移動対象からはずす。
 * onLoadイベント時に呼び出される。
 */
function tabIndex() {
    var elements = document.getElementsByTagName('INPUT');
    for( i=0; i<elements.length; i++ ){
        if(elements[i].getAttribute('readOnly')){
            elements[i].tabIndex = "-1";
        }
    }
}
