package murata.ps.pz.tool001;

import java.io.File;

import junit.extensions.TestSetup;
import junit.framework.Test;
import junit.framework.TestSuite;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import murata.co.producttest.controller.ProductTestController;
import murata.co.producttest.controller.ProductTestControllerImpl;
import murata.co.producttest.persist.db.DBImporter;
import murata.co.producttest.persist.db.DBImporterImpl;
import murata.co.producttest.persist.excel.ExcelExporterImpl;
import murata.co.producttest.persist.excel.ExcelSheetWriterImpl;
import murata.co.producttest.persist.excel.writer.NormalEvidenceWriter;
import murata.co.test.producttest.testcase.AbstractPGMTestCase;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;
import org.junit.BeforeClass;

/**
 * ���e�X�gFW��VFW�ɏ悹������B
 * @author Y.Hatanaka
 * @version $Id$
 * @since JDK5.0
 */
public class ConvertNewTestFW extends AbstractPGMTestCase {

    /**
     * �e�X�g�p�f�[�^�t�@�C���p�X�̎擾�B
     * <br />
     *
     * @return String �e�X�g�p�f�[�^�t�@�C���p�X
     */
    public String getTestDataFilePath() {
        return DATA_PATH;
    }

    /** tool01�̃p�X */
    private final static String WORKSPACE_PATH = "C:/eclipse/workspace/tool001/src/test/resources/";

    /** �e�X�g�f�[�^�t�@�C���p�X */
    private final static String DATA_PATH = "murata/ps/application/data";

    /** �����f�[�^�e���v���[�g */
    private final static String INPUT_TP_TEPLATE_FILENAME = "TP_TEMPLATE.xls";

    /** �����f�[�^�e���v���[�g */
    //    private final static String INPUT_TE_TEPLATE_FILENAME = "TE_TEMPLATE.xls";

    /** �f�[�^����R���g���[���N���X(ProductTestController) */
    private ProductTestController controller;

    /**
     * �R���X�g���N�^�B
     * <br />
     *
     * @param arg0 �N������
     */
    public ConvertNewTestFW(String arg0) {
        super(arg0);
    }

    /**
     * �e�X�g�P�[�X���̏��������B
     * <br />
     *
     * @throws Exception ��O������
     */
    @BeforeClass
    public void setUp() throws Exception {
        super.setUp();
        // �R���g���[���N���X����
        if (controller == null) {
            controller = new ProductTestControllerImpl();
        }

        ExcelSheetWriterImpl excelSheetWriter = new NormalEvidenceWriter();
        DBImporter dbImporter = new DBImporterImpl();
        ExcelExporterImpl excelExporter = new ExcelExporterImpl();
        excelExporter.setExNormalWriter(excelSheetWriter);
        controller.setDbImporter(dbImporter);
        controller.setExcelExporter(excelExporter);
    }

    /**
     * �e�X�g�X�C�[�g��`�B
     * <br />
     *
     * @return TestSetup Test�N���X
     */
    public static Test suite() {
        TestSetup setup = new TestSetup(new TestSuite(ConvertNewTestFW.class)) {

            public void setUp() throws Exception {
                oneTimeSetUp();
            }

            public void tearDown() throws Exception {
                oneTimeTearDown();
            }
        };

        return setup;
    }

    /**
     * �e�X�g���s��PGM�N���X���̎擾�B
     * <br />
     *
     * @return String PGM�N���X��
     */
    public String getTestBeanName() {
        final int subLength = "Test".length();
        String sClassName =
            WordUtils.uncapitalize(this.getClass().getSimpleName());
        return sClassName.substring(0, sClassName.length() - subLength);
    }

    /**
     * execute�e�X�g�P�[�X1�̃e�X�g�B
     *
     * @throws Exception �e�X�g���ɔ���������O
     */
    public void testExecute1() throws Exception {

        // ���O�f�[�^���擾
        File xmlFile = new File(WORKSPACE_PATH + getTestDataFilePath());
        File[] xmlList = null;
        if (xmlFile.isDirectory()) {
            xmlList = xmlFile.listFiles();
        } else {
            System.out.println(WORKSPACE_PATH + getTestDataFilePath() + "���m�F���Ă��������B");
            return;
        }

        for (int i = 0; i < xmlList.length; i++) {
            if (xmlList[i].getName().indexOf("Default") > 0
                && xmlList[i].getName().endsWith(".xml")) {

                // Default0�̎��̓X�L�b�v
                if (xmlList[i].getName().indexOf("Default0") > 0) {
                    continue;
                }

                // TP�t�@�C���쐬 //

                // ��U�Ώۂ̃e�[�u�����폜�iDefault0���g�p�j
                String default0File =
                    StringUtils.left(xmlList[i].getName(), 30) + "0.xml";
                cleanInsertDataFromXml(getTestDataFilePath() + "/"
                    + default0File);

                // xml�̃f�[�^�𓊓�
                if (this.getClass().getClassLoader().getResourceAsStream(
                    getTestDataFilePath() + "/" + xmlList[i].getName()) != null) {
                    cleanInsertDataFromXml(getTestDataFilePath() + "/"
                        + xmlList[i].getName());
                }
                System.out.println(xmlList[i] + "����");

                // TP_XXXnnnn.xls�ɏo��
                WritableWorkbook writeWorkBook =
                    controller.makeWritingWorkFile(this
                        .getNewFileName(xmlList[i].getName()),
                        WORKSPACE_PATH, INPUT_TP_TEPLATE_FILENAME, null);

                // �������ݗp�V�[�g�𐶐�����B
                WritableSheet sheet = this.makeSheet(writeWorkBook, "���O�f�[�^");

                // Excel�ɏo��
                NormalEvidenceWriter evidenceWriter =
                    new NormalEvidenceWriter();
                evidenceWriter.createExcelFromTableInfoVOs(sheet, controller
                    .importDbDataFromDb(), null);

                if (writeWorkBook != null) {
                    writeWorkBook.write();
                    writeWorkBook.close();
                    writeWorkBook = null;
                }

                //                // TE�t�@�C���쐬 //
                //
                //                // ���O�u������
                //                String checkDbFile =
                //                    StringUtils.replace(xmlList[i].getName(), "Default",
                //                        "CheckDb");
                //
                //                // ���݃`�F�b�N
                //                File file = new File(INPUT + "/" + checkDbFile);
                //                if (!(file.exists() && file.isFile())) {
                //                    continue;
                //                }
                //
                //                // TE_XXXnnnn.xls�ɏo��
                //                writeWorkBook =
                //                    controller.makeWritingWorkFile(this
                //                        .getNewFileName(checkDbFile), INPUT_TEPLATE_PATH,
                //                        INPUT_TE_TEPLATE_FILENAME, null);
                //
                //                //                // �������ݗp�V�[�g�𐶐�����B
                //                //                WritableSheet sheet1 = this.makeSheet(writeWorkBook, "�����ODB");
                //                //
                //                //                // Excel�ɏo��
                //                //                evidenceWriter = new NormalEvidenceWriter();
                //                //                evidenceWriter.createExcelFromTableInfoVOs(sheet1, controller
                //                //                    .importDbDataFromDb(), null);
                //                //
                //                // ��U�Ώۂ̃e�[�u�����폜�iDefault0���g�p�j
                //                cleanInsertDataFromXml(getTestDataFilePath() + "/"
                //                    + default0File);
                //
                //                // xml�̃f�[�^�𓊓�
                //                if (this.getClass().getClassLoader().getResourceAsStream(
                //                    getTestDataFilePath() + "/" + xmlList[i].getName()) != null) {
                //                    cleanInsertDataFromXml(getTestDataFilePath() + "/"
                //                        + checkDbFile);
                //                }
                //
                ////                // �������ݗp�V�[�g�𐶐�����B
                ////                WritableSheet sheet2 = this.makeSheet(writeWorkBook, "������DB");
                ////
                ////                evidenceWriter.createExcelFromTableInfoVOs(sheet2, controller
                ////                    .importDbDataFromDb(), null);
                //
                //                // �G�r�f���XExcel�֏����o���������s��(����DB)
                //                controller.exportTableInfoVoToExcel(writeWorkBook,
                //                    Constants.SHEET_NAME_AFT_DB, controller
                //                        .importDbDataFromDb());
                //
                //                if (writeWorkBook != null) {
                //                    writeWorkBook.write();
                //                    writeWorkBook.close();
                //                    writeWorkBook = null;
                //                }
            }
        }
    }

    /**
     * ���e�X�gFW�̎��O�f�[�^�t�@�C��������V�e�X�gFW�̎��O�f�[�^�t�@�C�������擾����B
     * @param oldFileName ���t�@�C����
     * @return String �V�t�@�C����
     */
    private String getNewFileName(String oldFileName) {

        String defaultStr = "Default";
        String cehckDbStr = "CheckDb";
        String head = "";

        int endIndex = oldFileName.indexOf(".xml");
        int startIndex = oldFileName.indexOf(defaultStr);
        if (startIndex < 0) {
            startIndex = oldFileName.indexOf(cehckDbStr);
            startIndex = startIndex + cehckDbStr.length();
            head = "TE_";
        } else {
            startIndex = startIndex + defaultStr.length();
            head = "TP_";
        }

        String testID =
            StringUtils.substring(oldFileName, startIndex, endIndex);
        String productID = StringUtils.left(oldFileName, 7);

        return head + productID.toUpperCase() + "(" + testID + ").xls";

    }

    /**
     * �o�̓V�[�g����
     * @param workBook ��Ƃ��s�����[�N�u�b�N
     * @param sheetName �V�[�g����
     * @return WritableSheet WritableSheet
     */
    private WritableSheet makeSheet(WritableWorkbook workBook, String sheetName) {

        // �V�[�g�N���X����
        WritableSheet sheet = workBook.getSheet(sheetName);

        // ���݊m�F
        if (sheet == null) {
            // �V�[�g�ʒu
            int index = 0;

            // �ꏊ�m�F
            WritableSheet[] sheets = workBook.getSheets();

            if (sheets != null && sheets.length != 0) {
                index = sheets.length + 1;
            }
            // �V�[�g�𐶐�
            sheet = workBook.createSheet(sheetName, index);
        }

        // ���ʂ�ԋp����
        return sheet;
    }
}
