<%@ page contentType="text/html; charset=UTF-8"%>

/*
 * [↑]、[↓]、[Ctrl][↑]、[Ctrl][↓]押下時にフォーカスを移動させる。
 * onkeydownイベント時に呼び出される。
 */
function jumpTo(currentid) {
    var id = '';
    //処理対象外の項目が指定されている場合は処理しない
    if(!isFocusable(document.getElementById(currentid))){
      return;
    }
    var tblidx = currentid.match(/^TBL[0-9]+/);
    //一覧内で処理が呼び出された場合
    if(tblidx != null){

      //配列のインデックス
      var arrayidx = null;
      for(i = 0; i < idArray.length; i++){
        if(idArray[i][0].indexOf(tblidx) != -1){
          arrayidx = i;
          break;
        }
      }
      //Ctrl
      if(event.ctrlKey == true){
       id = arrayJumpTo(idArray[arrayidx][0], true);
      }else{
        // Up又はDown
        if (event.keyCode == 38 || event.keyCode == 40){
          id = rowJumpTo(currentid);
        }
      }
    //一覧外で処理が呼び出された場合
    }else{
      //ctrlKeyが押下されていない場合のみフォーカスを移動させる
      if (event.ctrlKey == false) {
        id = arrayJumpTo(currentid, false);
      }
    }
    //実在するidが設定されている場合フォーカス移動させる
    if(document.getElementById(id)) {
      document.getElementById(id).focus();
    }
}
/*
 * [↑][↓]押下時のフォーカス移動先をjsp内のidArray配列から取得する
 *
 *  引数のlistFlgは、一覧部で［Ctrl］+［↑］又は［Ctrl］+［↓］を押下した場合。又は
 *  一覧部の最上段で［↑］又は最下段で［↓］を押下した場合にtrueを設定する。
 */
function arrayJumpTo(currentid, listFlg){
    var id = '';
    var tblidx = null;


    if(!listFlg){
      tblidx = currentid.match(/^TBL[0-9]+/);
    }

    //再帰処理で1回目にフォーカス対象となるidにフォーカスが当てられず、
    //2回目以降のフォーカス対象が一覧部であった場合
    if(tblidx != null){
      return rowJumpTo(currentid);
    }else{
      //配列のインデックス
      var arrayidx = null;
      for(i = 0; i < idArray.length; i++){
        for(j = 0; j < idArray[i].length; j++){
          if(currentid == idArray[i][j]){
            arrayidx = i;
            break;
          }
        }
        if(arrayidx!=null){
          break;
        }
      }
      // Up
      if (event.keyCode == 38){
        //一行上の一番左側のカラムをidに設定する
        if(arrayidx!=null)--arrayidx;
        if(arrayidx!=null && 0 <= arrayidx && arrayidx <idArray.length){
          id = idArray[arrayidx][0];
        }
      }
      // Down
      if (event.keyCode == 40){
         //一行下の一番左側のカラムをidに設定する
         if(arrayidx!=null)++arrayidx;
         if(arrayidx!=null && 0 <= arrayidx && arrayidx <idArray.length){
           id = idArray[arrayidx][0];
         }
      }
      var elementbyid = document.getElementById(id);
      if(elementbyid == null){
        return ;
      }else if(!isFocusable(elementbyid)){
        return arrayJumpTo(id,false);
      }
      return id;
    }
}
/*
 * [↑][↓]押下時のフォーカス移動先を一覧部の行番号から取得する
 *
 */
function rowJumpTo(currentid) {
    var id = '';

    var rowidx = currentid.substring(currentid.indexOf("R")+1, currentid.indexOf("C"));

    // Up
    if (event.keyCode == 38){
      id = currentid.replace("R"+rowidx, "R"+(--rowidx));
    }
    // Down
    if (event.keyCode == 40){
      id = currentid.replace("R"+rowidx, "R"+(++rowidx));
    }

    //idが画面内にない場合
    var elementbyid = document.getElementById(id);
    if(elementbyid == null){
      //配列のインデックス
      var arrayidx = null;
      var tblidx = id.match(/^TBL[0-9]+/);
      for(i = 0; i < idArray.length; i++){
        if(idArray[i][0].indexOf(tblidx) != -1){
          arrayidx = i;
          break;
        }
      }
      return arrayJumpTo(idArray[arrayidx][0], true);
    }else if(!isFocusable(elementbyid)){
      return rowJumpTo(id);
    }
    return id;
}
/*
 * 指定のelementがフォーカス移動対象であるかチェックする
 *
 */
function isFocusable(element){
  //フォーカス移動不可項目を追加してください
  if (element.type == 'hidden') {
    return false;
  }
  else if( element.disabled){
    return false;
  }
  else if(element.getAttribute('readOnly')){
    return false;
  }
  return true;
}