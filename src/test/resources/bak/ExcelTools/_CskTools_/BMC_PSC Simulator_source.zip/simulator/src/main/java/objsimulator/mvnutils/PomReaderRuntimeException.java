package objsimulator.mvnutils;


public class PomReaderRuntimeException extends Throwable {
    public PomReaderRuntimeException(String errmsg) {
        super(errmsg);
    }
}
