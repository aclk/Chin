package objsimulator.mvnutils;

import java.io.File;


public interface PomReader {
    Pom read(File pomFile, File mavenHomeDir) throws PomReaderRuntimeException;
}
