package objsimulator.test;

import java.io.File;
import java.util.List;

import junit.framework.TestCase;
import objsimulator.dao.ApplicationContextDao;
import objsimulator.dao.impl.ApplicationContextDaoImpl;
import objsimulator.exception.DaoRuntimeException;
import objsimulator.model.BeanAttribute;


public class ApplicationContextTest extends TestCase {
    public void testRun() {
        ApplicationContextDao dao = new ApplicationContextDaoImpl();
        try {
            dao.dumpToXML(new File("./resources/application-context-dao.xml"));
            dao.initializeByXML(new File("./resources/application-context-dao.xml"));

            List<BeanAttribute> results = dao.findByName("common");
            for(BeanAttribute beanAttr : results) {
                System.out.println(beanAttr.getName()+" / "+beanAttr.getType());
            }
        } catch (DaoRuntimeException e) {
            e.printStackTrace();
        }
    }
}
