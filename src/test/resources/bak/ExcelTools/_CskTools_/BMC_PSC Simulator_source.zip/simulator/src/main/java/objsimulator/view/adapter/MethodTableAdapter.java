package objsimulator.view.adapter;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.DefaultTableModel;

import objsimulator.model.MethodAttribute;


public class MethodTableAdapter extends DefaultTableModel {
    private List<MethodAttribute> bean = new ArrayList<MethodAttribute>();
    private String[] columns = new String[] {"�߂�l","���\�b�h��","����"};

    public MethodTableAdapter(List<MethodAttribute> bean) {
        this.bean = bean;
    }

    public List<MethodAttribute> getBean() {
        return bean;
    }

    public void setBean(List<MethodAttribute> bean) {
        this.bean = bean;
    }

    public int getColumnCount() {
        return this.columns.length;
    }

    public String getColumnName(int column) {
        return this.columns[column];
    }

    public int getRowCount() {
        if( this.bean == null ) { return super.getRowCount(); }
        return this.bean.size();
    }

    public Object getValueAt(int row, int column) {
        if( this.bean == null ) { return super.getValueAt(row, column); }

        MethodAttribute methodAttr = this.bean.get(row);
        switch(column) {
            case 0: return methodAttr.getReturnType();
            case 1: return methodAttr.getName();
            case 2: return methodAttr.getParamaterString();
            default: return null;
        }
    }

    public boolean isCellEditable(int row, int column) {
        return false;
    }

}
