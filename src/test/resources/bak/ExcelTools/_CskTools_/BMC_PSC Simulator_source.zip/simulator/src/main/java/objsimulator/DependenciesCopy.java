package objsimulator;

import java.io.File;
import java.io.IOException;

import org.apache.tools.ant.util.FileUtils;


public class DependenciesCopy {

    public static void main(String[] args) {
        String allPath = System.getProperty("java.class.path");
        String[] pathList = allPath.split(";");

        File dir = new File(args[0]);
        if( !dir.isDirectory() ) {
            throw new RuntimeException("�R�s�[��f�B���N�g�����w�肵�ĉ������B:");
        }

        for(String path : pathList) {
            if( !path.endsWith(".jar") ) { continue; }

            File file = new File(path);
            System.out.println("�R�s�[���F"+path);
            try {
                FileUtils.getFileUtils().copyFile(file, new File(dir.getPath()+"/"+file.getName()));
            } catch (IOException e) {
                throw new RuntimeException(e.getMessage());
            }
        }
    }

}
