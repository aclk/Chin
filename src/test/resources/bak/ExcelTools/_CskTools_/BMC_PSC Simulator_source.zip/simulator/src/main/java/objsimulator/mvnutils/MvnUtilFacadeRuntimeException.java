package objsimulator.mvnutils;


public class MvnUtilFacadeRuntimeException extends Throwable {
    public MvnUtilFacadeRuntimeException(String errmsg) {
        super(errmsg);
    }
}
