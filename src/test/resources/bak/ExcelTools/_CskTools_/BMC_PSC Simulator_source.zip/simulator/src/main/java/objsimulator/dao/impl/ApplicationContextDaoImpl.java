package objsimulator.dao.impl;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import objsimulator.dao.ApplicationContextDao;
import objsimulator.exception.DaoRuntimeException;
import objsimulator.model.BeanAttribute;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;


public class ApplicationContextDaoImpl implements ApplicationContextDao {
    private List<BeanAttribute> beanAttributes = new ArrayList<BeanAttribute>();

    public List<BeanAttribute> findByName(String keyword) throws DaoRuntimeException {
        List<BeanAttribute> results = new ArrayList<BeanAttribute>();

        Pattern pattern = Pattern.compile(".*"+keyword+".*");
        boolean isHit = false;
        for(BeanAttribute beanAttr : this.beanAttributes) {
            if( pattern.matcher(beanAttr.getName()).find() ) {
                results.add( beanAttr );
                isHit = true;
            }else if( pattern.matcher(beanAttr.getType()).find() ){
                results.add( beanAttr );
                isHit = true;
            }
        }
        if( !isHit ) {
            try {
                Class type = Class.forName(keyword);
                BeanAttribute beanAttr = new BeanAttribute();
                beanAttr.setName(null);
                beanAttr.setType(type.getCanonicalName());
                results.add(beanAttr);
            } catch (ClassNotFoundException e) {}
        }

        return results;
    }

    public void dumpToXML(File file) throws DaoRuntimeException {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(new File("./resources/header-context.xml")), "utf-8"));
            String line = null;
            String template = "";
            while((line=reader.readLine()) != null) {
                template += line+"\n";
            }
            reader.close();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File("./resources/dynamic-context.xml")),"utf-8"));
            template += "<beans></beans>\n";
            writer.write(template);
            writer.flush();
            writer.close();
        }catch(Exception e) {
            throw new DaoRuntimeException(e.getMessage());
        }

        String path = "./resources/application-context.xml";
        ApplicationContext context = (ApplicationContext)new FileSystemXmlApplicationContext(path).getBean("context");

        for(String name : context.getBeanDefinitionNames()) {
            BeanAttribute beanAttr = new BeanAttribute();
            beanAttr.setName( name );
            if( context.getType(name) == null ) { continue; }

            beanAttr.setType(context.getType(name).getCanonicalName());
            this.beanAttributes.add( beanAttr );
        }

        XMLEncoder encoder;
        try {
            encoder = new XMLEncoder(new FileOutputStream(file));
            encoder.writeObject(this.beanAttributes);
            encoder.flush();
            encoder.close();
        } catch (FileNotFoundException e) {
            throw new DaoRuntimeException(e.getMessage());
        }
    }

    public void initializeByXML(File file) throws DaoRuntimeException {
        XMLDecoder decoder;
        try {
            decoder = new XMLDecoder(new FileInputStream(file));
            this.beanAttributes = (List<BeanAttribute>)decoder.readObject();
            decoder.close();
        } catch (FileNotFoundException e) {
            throw new DaoRuntimeException(e.getMessage());
        }
    }

}
