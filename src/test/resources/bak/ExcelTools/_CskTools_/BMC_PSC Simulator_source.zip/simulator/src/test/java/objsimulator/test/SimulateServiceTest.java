package objsimulator.test;
import junit.framework.TestCase;
import objsimulator.exception.ServiceRuntimeException;
import objsimulator.service.SimulateService;



public class SimulateServiceTest extends TestCase {

    public void testRun() {
        try {
            SimulateService service = new SimulateService();
            service.invokeMethodAndDisplayReturnValue( new String[]{"murata.co.bmc.calendarbmc.CalendarBMC"}, "return calendarBMC.getDateOfProcessing();");
        } catch (ServiceRuntimeException e) {
            throw new RuntimeException(e);
        }
    }
}
