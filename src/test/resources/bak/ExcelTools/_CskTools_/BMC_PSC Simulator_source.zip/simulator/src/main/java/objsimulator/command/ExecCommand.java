package objsimulator.command;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

import objsimulator.exception.CommandRuntimeException;
import objsimulator.view.SimulateWindow;


public class ExecCommand implements Command {

    public void execute(Object view) throws CommandRuntimeException {
        final SimulateWindow window = (SimulateWindow)view;

        try {
            Process process = Runtime.getRuntime().exec("./bootstrap.bat");
            try {
                process.waitFor();
            } catch (InterruptedException e1) {
                throw new CommandRuntimeException(e1.getMessage());
            }

            String src = window.getScriptTxt().getText();
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File("./tmp/script.txt")), "MS932"));
            writer.write(src);
            writer.flush();
            writer.close();

            String[] tmp = window.getDiTxt().getText().split("\n");
            String di = "";
            for(int i=0; i<tmp.length; i++) {
                String line = tmp[i].trim();
                if( line.length() == 0 ) {continue;}

                di += line;
                if( i != tmp.length-1 ) { di += ","; }
            }

            String cmd = "./boot.bat -file \"./tmp/script.txt\" -di \""+di+"\" ";

            process = Runtime.getRuntime().exec(cmd);
            final InputStream in = process.getInputStream();
            final InputStream errIn = process.getErrorStream();
            final BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            final BufferedReader errReader = new BufferedReader(new InputStreamReader(errIn));
            window.getOutputTxt().setText("");

            new Thread(new Runnable() {
                public void run() {
                    try {
                        String line="";
                        while ((line = reader.readLine()) != null) {
                            System.out.println(line);
                            window.getOutputTxt().setText(
                                window.getOutputTxt().getText()+"\n"+line );
                        }
                    }catch(Exception e) {
                        e.printStackTrace();
                    }finally {
                        try {
                            in.close();
                        }catch(Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }).start();

            new Thread(new Runnable() {
                public void run() {
                    try {
                        String line="";
                        while ((line = errReader.readLine()) != null) {
                            System.out.println(line);
                            window.getOutputTxt().setText(
                                window.getOutputTxt().getText()+"\n"+line );
                        }
                    }catch(Exception e) {
                        e.printStackTrace();
                    }finally {
                        try {
                            errIn.close();
                        }catch(Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            }).start();

            try {
                process.waitFor();
            }catch(Exception e1) {
                throw new RuntimeException(e1.getMessage());
            }

        } catch (IOException e1) {
            throw new CommandRuntimeException(e1.getMessage());
        }
    }

}
