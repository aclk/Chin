package objsimulator.service;

import groovy.lang.Binding;
import groovy.lang.GroovyClassLoader;
import groovy.lang.GroovyObject;
import groovy.lang.GroovyRuntimeException;
import groovy.lang.GroovyShell;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;

import objsimulator.exception.ServiceRuntimeException;
import objsimulator.serializer.TxtSerializer;
import objsimulator.serializer.XSerializeRuntimeException;
import objsimulator.serializer.XSerializer;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class SimulateService {
    public SimulateService() throws ServiceRuntimeException {
        try {
            Velocity.init();
        } catch (Exception e) {
            e.printStackTrace();
            throw new ServiceRuntimeException(e.getMessage());
        }
    }

    public void invokeMethodAndDisplayReturnValue(String[] diBeans, String src) throws ServiceRuntimeException {
        Object result = this.invokeMethod(diBeans, src);

        XSerializer xserializer = new TxtSerializer();
        System.out.println("\n******** �߂�l ********");
        try {
            xserializer.write(System.out, result);
        } catch (XSerializeRuntimeException e) {
            throw new ServiceRuntimeException(e.getMessage());
        }
    }

    public Object invokeMethod(String[] diBeans, String src) throws ServiceRuntimeException {
        String path = "./resources/application-context.xml";
        File file = new File("./resources/test_groovy.txt");
        String text="";

        //Groovy�X�N���v�g�̓ǂݍ���
        text = this.buildScript(diBeans, src);
        BufferedWriter writer;
        try {
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File("./script.txt"))));
            writer.write(text);
            writer.flush();
            writer.close();
        } catch (FileNotFoundException e1) {
            throw new ServiceRuntimeException(e1.getMessage());
        } catch (IOException e) {
            throw new ServiceRuntimeException(e.getMessage());
        }

        //Groovy�̃Z�b�g�A�b�v
        Binding binding = new Binding();
        GroovyShell shell = new GroovyShell(binding);

        try {
            GroovyObject dammyResult = (GroovyObject)shell.evaluate(text);
            Thread.currentThread().setContextClassLoader(dammyResult.getClass().getClassLoader());

            GroovyClassLoader loader = new GroovyClassLoader( Thread.currentThread().getContextClassLoader() );
            Class testClass = loader.loadClass("objsimulator.model.SimulateObject");
            Thread.currentThread().setContextClassLoader(loader);

            //�X�v�����O�̍\���t�@�C���𓮓I�ɐ���
            file = new File("./resources/template-context.xml");
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file),"MS932"));
            String line;
            text = "";
            while((line=reader.readLine()) != null) {
                text += line+"\n";
            }
            reader.close();

            //DI�̌���
            String diProperties = "";
            if( diBeans != null ) {
                for(String di : diBeans) {
                    di = di.trim();
                    if( di.length() == 0 ) {continue;}

                    String beanId = di.split(" ")[1].trim();
                    String property = beanId.replaceAll("[$]", "_");
                    String temp = "<property name=\""+property+"\" ref=\""+beanId+"\" />\n";
                    diProperties += temp;
                }
            }

            VelocityContext velocityContext = new VelocityContext();
            velocityContext.put("CLASS", testClass.getCanonicalName());
            velocityContext.put("DI", diProperties);
            StringWriter stringWriter = new StringWriter();
            Velocity.evaluate(velocityContext, stringWriter, "objsimulator", text);
            text = stringWriter.toString();

            file = new File("./resources/dynamic-context.xml");
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file)));
            writer.write(text);
            writer.flush();
            writer.close();

            System.out.println("\n******** �A�v���P�[�V�����R���e�L�X�g�̃��[�h ********");
            ApplicationContext context = (ApplicationContext)new FileSystemXmlApplicationContext(path).getBean("context");

            System.out.println("\n******** �e�X�g�R�[�h�̎��s ********");
            GroovyObject simulateObject = (GroovyObject)context.getBean("simulateObject");
            Object result = simulateObject.invokeMethod("invoke", null);

            return result;
        }catch(GroovyRuntimeException e) {
            throw new ServiceRuntimeException(e.getMessage());
        }catch(Exception e) {
            throw new ServiceRuntimeException(e.getMessage());
        }
    }

    public String buildScript(String[] diBeans, String src) throws ServiceRuntimeException {
        String text="package objsimulator.model;\n\n";

        //�����import�ꗗ���擾
        File file = new File("./resources/default_imports.txt");
        if( file.exists() ) {
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file),"MS932"));
                String line;
                while((line=reader.readLine()) != null) {
                    text += line+"\n";
                }
                reader.close();
            } catch (UnsupportedEncodingException e1) {
                throw new RuntimeException(e1);
            } catch (FileNotFoundException e1) {
                throw new RuntimeException(e1);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        //Groovy�X�N���v�g�̓ǂݍ���
        file = new File("./resources/groovy_template.txt");
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file),"MS932"));
            String line;
            while((line=reader.readLine()) != null) {
                text += line+"\n";
            }
            reader.close();
        } catch (UnsupportedEncodingException e1) {
            throw new RuntimeException(e1);
        } catch (FileNotFoundException e1) {
            throw new RuntimeException(e1);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


        //�v���p�e�B�̐ݒ�
        String properties = "";
        file = new File("./resources/groovy_property.txt");
        String propertyTemplate = "";
        //Groovy�X�N���v�g�̓ǂݍ���
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file),"MS932"));
            String line;
            while((line=reader.readLine()) != null) {
                propertyTemplate += line+"\n";
            }
            reader.close();
        } catch (UnsupportedEncodingException e1) {
            throw new RuntimeException(e1);
        } catch (FileNotFoundException e1) {
            throw new RuntimeException(e1);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        VelocityContext velocityContext = new VelocityContext();

        if( diBeans != null ) {
            for(String di : diBeans) {
                di = di.trim();
                if( di.length() == 0 ) {continue;}

                String interfaceName = di.split(" ")[0].trim();
                String beanId = di.split(" ")[1].trim().replaceAll("[$]", "_");
                String property = Character.toUpperCase(beanId.toCharArray()[0])+beanId.substring(1);

                String prop = new String(propertyTemplate);

                velocityContext.put("CLASS", interfaceName);
                velocityContext.put("FIELD", beanId);
                velocityContext.put("PROPERTY", property);

                StringWriter stringWriter = new StringWriter();
                try {
                    Velocity.evaluate(velocityContext, stringWriter, "objsimulator", prop);
                }catch(Exception e) {
                    throw new ServiceRuntimeException(e.getMessage());
                }
                prop = stringWriter.toString();

                properties += prop;
            }
        }

        velocityContext.put("PROPERTIES", properties);
        velocityContext.put("SOURCE", src);
        StringWriter stringWriter = new StringWriter();
        try {
            Velocity.evaluate(velocityContext, stringWriter, "objsimulator", text);
        }catch(Exception e) {
            throw new ServiceRuntimeException(e.getMessage());
        }
        text = stringWriter.toString();

        return text;
    }
}
