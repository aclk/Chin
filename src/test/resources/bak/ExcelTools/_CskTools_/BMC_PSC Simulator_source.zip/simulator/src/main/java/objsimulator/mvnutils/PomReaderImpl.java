package objsimulator.mvnutils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.regex.Pattern;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;



public class PomReaderImpl implements PomReader {
    public PomReaderImpl() {
        try {
            Velocity.init();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public Pom read(File pomFile, File mavenHomeDir) throws PomReaderRuntimeException {
        Map<String, Pom> readHistory = new HashMap<String, Pom>();
        return this._read(pomFile, mavenHomeDir, readHistory);
    }

    public Pom _read(File pomFile, File mavenHomeDir, Map<String, Pom> readHistory) throws PomReaderRuntimeException {
        if( readHistory.containsKey(pomFile.getAbsolutePath()) ) {
            return readHistory.get(pomFile.getAbsolutePath());
        }

        SAXParserFactory spfactory = SAXParserFactory.newInstance();
        SAXParser parser;
        Pom pom = new Pom();
        pom.setPomPath(pomFile.getAbsolutePath());
        readHistory.put(pomFile.getAbsolutePath(), pom);

        try {
            parser = spfactory.newSAXParser();

            File workPomFile = new File("./~pom.xml");
            workPomFile.deleteOnExit();

            //properties�̉���
            String pomText = "";
            String line;
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(pomFile)));
            while((line = reader.readLine()) != null) {
                pomText += line + "\n";
            }
            reader.close();

            Pattern pattern = Pattern.compile("<properties>");
            if( pattern.matcher(pomText).find() ) {
                for(int i=0; i<2; i++) {
                    StringReader strReader = new StringReader(pomText);
                    VelocityParser velocityParser = new VelocityParser();
                    parser.parse(pomFile, velocityParser);

                    try {
                        StringWriter writer = new StringWriter();
                        Velocity.evaluate(velocityParser.getContext(), writer, "mvnutils", strReader);
                        writer.flush();
                        pomText = writer.toString();
                        writer.close();
                    } catch (ParseErrorException e) {
                        throw new PomReaderRuntimeException(e.getMessage());
                    } catch (MethodInvocationException e) {
                        throw new PomReaderRuntimeException(e.getMessage());
                    } catch (ResourceNotFoundException e) {
                        throw new PomReaderRuntimeException(e.getMessage());
                    } catch (Exception e) {
                        throw new PomReaderRuntimeException(e.getMessage());
                    }finally {
                        strReader.close();
                    }
                }
            }

            BufferedWriter fwriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(workPomFile),"utf-8"));
            fwriter.write(pomText);
            fwriter.flush();
            fwriter.close();

            parser.parse(workPomFile, new PomParser(pom));
        } catch (ParserConfigurationException e) {
            throw new PomReaderRuntimeException(e.getMessage());
        } catch (SAXException e) {
            throw new PomReaderRuntimeException(e.getMessage());
        } catch (IOException e) {
            throw new PomReaderRuntimeException(e.getMessage());
        }

        //�epom�̃��[�h
        if( pom.getParent() != null ) {
            File parentPomFile = new File(mavenHomeDir.getPath()+"/repository/"+pom.getParent().getGroupId()+"/"+pom.getParent().getArtifactId()+"/"+pom.getParent().getVersion()+"/"+pom.getParent().getArtifactName()+".pom");
            pom.setParent( new PomReaderImpl()._read(parentPomFile, mavenHomeDir, readHistory) );
        }
        //�ˑ��֌Wpom�̃��[�h
        List<Pom> dependencies = new ArrayList<Pom>();
        for(Pom dep : pom.getDependencies()) {
            File depPomFile = new File(mavenHomeDir.getPath()+"/repository/"+dep.getGroupId()+"/"+dep.getArtifactId()+"/"+dep.getVersion()+"/"+dep.getArtifactName()+".pom");
            if( !depPomFile.exists() ) { continue; }

            dependencies.add( new PomReaderImpl()._read(depPomFile, mavenHomeDir, readHistory ) );
        }

        pom.setDependencies( dependencies );

        //Jar�̃`�F�b�N
        String jarPath = pomFile.getParent()+"/"+pom.getArtifactName()+".jar";
        if( new File(jarPath).exists() ) {
            pom.setJarPath(jarPath);
        }

        return pom;
    }

    private class PomParser extends DefaultHandler {
        private Stack<String> target = new Stack<String>();
        private Pom pom;
        private Pom dependency;
        private String text;

        public PomParser(Pom pom) {
            this.pom = pom;
        }

        public void characters(char[] ch, int start, int length) throws SAXException {
            this.text = new String(ch, start, length);
        }

        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            this.target.push(qName);

            if( qName.equals("dependency") ) {
                this.dependency = new Pom();
            }
        }

        public void endElement(String uri, String localName, String qName) throws SAXException {
            this.target.pop();

            if( !this.target.isEmpty() ) {
                if( this.target.peek().equals("project") ) {
                    if( !qName.equals("parent") && !qName.equals("dependencies") ) {
                        try {
                            BeanUtils.setProperty(this.pom, qName, this.text);
                        } catch (IllegalAccessException e) {
                            throw new SAXException(e);
                        } catch (InvocationTargetException e) {
                            throw new SAXException(e);
                        }
                    }
                }else if( this.target.peek().equals("parent") ) {
                    try {
                        if( this.pom.getParent() == null ) { this.pom.setParent(new Pom()); }
                        BeanUtils.setProperty(this.pom.getParent(), qName, this.text);
                    } catch (IllegalAccessException e) {
                        throw new SAXException(e);
                    } catch (InvocationTargetException e) {
                        throw new SAXException(e);
                    }
                }else if( this.target.peek().equals("dependency") ) {
                    try {
                        BeanUtils.setProperty(this.dependency, qName, this.text);
                    } catch (IllegalAccessException e) {
                        throw new SAXException(e);
                    } catch (InvocationTargetException e) {
                        throw new SAXException(e);
                    }
                }else if( this.target.peek().equals("dependencies") ) {
                    this.pom.getDependencies().add(this.dependency);
                }
            }
        }
    }

    private class VelocityParser extends DefaultHandler {
        private String text;
        private VelocityContext context;
        private Stack<String> target = new Stack<String>();

        public VelocityParser() {
            this.context = new VelocityContext();
        }

        public void characters(char[] ch, int start, int length) throws SAXException {
            this.text = new String(ch, start, length);
        }

        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            this.target.push(qName);
        }

        public void endElement(String uri, String localName, String qName) throws SAXException {
            this.target.pop();

            if( !this.target.isEmpty() && this.target.peek().equals("properties") ) {
                //System.out.println("Props:"+qName+"/"+this.text);
                context.put(qName, this.text);
            }
        }


        public VelocityContext getContext() {
            return context;
        }


    }

}