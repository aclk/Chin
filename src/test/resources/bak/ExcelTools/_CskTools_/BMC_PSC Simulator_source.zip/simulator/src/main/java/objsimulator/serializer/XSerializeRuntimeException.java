package objsimulator.serializer;


public class XSerializeRuntimeException extends Throwable {
    public XSerializeRuntimeException(String msg) {
        super(msg);
    }
}
