package objsimulator.exception;

/**
 * ���ۗ�O
 * @author T.Umeda
 * @version $Id: AbstractException.java 11614 2007-07-18 05:31:12Z A1M4MEM138 $
 * @since JDK5.0
 */
public class AbstractException extends Throwable {
    /**
     * ���ۗ�O
     * @param message ��O���b�Z�[�W
     */
    public AbstractException(String message) {
        super(message);
    }
}
