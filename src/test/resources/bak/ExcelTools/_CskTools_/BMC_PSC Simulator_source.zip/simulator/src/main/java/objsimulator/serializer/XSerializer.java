package objsimulator.serializer;

import java.io.PrintStream;


public interface XSerializer {
    void write(PrintStream out, Object bean) throws XSerializeRuntimeException;
}
