package objsimulator.service;

import java.io.File;
import java.util.List;

import javax.swing.JOptionPane;

import objsimulator.dao.ApplicationContextDao;
import objsimulator.dao.impl.ApplicationContextDaoImpl;
import objsimulator.exception.DaoRuntimeException;
import objsimulator.exception.ServiceRuntimeException;
import objsimulator.model.BeanAttribute;


public class BeanSearchService {
    private ApplicationContextDao dao;

    public List<BeanAttribute> findByName(String keyword) throws ServiceRuntimeException {
        try {
            if( this.dao == null ) {
                this.dao = new ApplicationContextDaoImpl();
                this.dao.initializeByXML(new File("./resources/application-context-dao.xml"));
            }

            return this.dao.findByName(keyword);
        } catch (DaoRuntimeException e) {
            throw new ServiceRuntimeException(e.getMessage());
        }
    }

    public static void main(String[] args) {
        ApplicationContextDao dao = new ApplicationContextDaoImpl();
        try {
            dao.dumpToXML(new File("./resources/application-context-dao.xml"));
        } catch (DaoRuntimeException e) {
            JOptionPane.showMessageDialog(null, e.getMessage(), "BMC_PSC Simulator Exception", JOptionPane.ERROR);
        }
    }
}
