package objsimulator.model;

import java.util.ArrayList;
import java.util.List;


public class MethodAttribute {
    private String returnType;
    private String name;
    private List<String> parameters = new ArrayList<String>();
    private BeanAttribute bean;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getParameters() {
        return parameters;
    }

    public void setParameters(List<String> parameters) {
        this.parameters = parameters;
    }

    public String getReturnType() {
        return returnType;
    }

    public void setReturnType(String returnType) {
        this.returnType = returnType;
    }

    public String getParamaterString() {
        String ret = "";
        for(int i=0; i<this.parameters.size(); i++) {
            ret += this.parameters.get(i);
            if( i != this.parameters.size()-1 ) {
                ret += ", ";
            }
        }
        return ret;
    }


    public BeanAttribute getBean() {
        return bean;
    }


    public void setBean(BeanAttribute bean) {
        this.bean = bean;
    }


}
