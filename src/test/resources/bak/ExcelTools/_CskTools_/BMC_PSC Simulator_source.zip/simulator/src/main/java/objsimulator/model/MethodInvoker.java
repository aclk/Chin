package objsimulator.model;

import org.springframework.transaction.annotation.Transactional;


public interface MethodInvoker {
    @Transactional(readOnly = false)
    Object invoke();
}
