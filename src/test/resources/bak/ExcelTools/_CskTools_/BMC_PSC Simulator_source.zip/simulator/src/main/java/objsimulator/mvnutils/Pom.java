package objsimulator.mvnutils;

import java.util.ArrayList;
import java.util.List;


public class Pom {
    private String pomPath;
    private String jarPath;
    private String name;
    private String description;
    private String modelVersion;
    private String groupId;
    private String artifactId;
    private String version;
    private String scope;
    private String optional;
    private Pom parent;
    private List<Pom> dependencies = new ArrayList<Pom>();

    public String getArtifactName() {
        return this.getArtifactId()+"-"+this.getVersion();
    }

    public String getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(String artifactId) {
        this.artifactId = artifactId;
    }

    public List<Pom> getDependencies() {
        return dependencies;
    }

    public void setDependencies(List<Pom> dependencies) {
        this.dependencies = dependencies;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getJarPath() {
        return jarPath;
    }

    public void setJarPath(String jarPath) {
        this.jarPath = jarPath;
    }

    public String getModelVersion() {
        return modelVersion;
    }

    public void setModelVersion(String modelVersion) {
        this.modelVersion = modelVersion;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Pom getParent() {
        return parent;
    }

    public void setParent(Pom parent) {
        this.parent = parent;
    }

    public String getPomPath() {
        return pomPath;
    }

    public void setPomPath(String pomPath) {
        this.pomPath = pomPath;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getOptional() {
        return optional;
    }

    public void setOptional(String optional) {
        this.optional = optional;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }
}
