package objsimulator.serializer;

import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.beanutils.PropertyUtilsBean;


public class TxtSerializer implements XSerializer {
    private String propertyTag = "�v���p�e�B:";
    private String valueTag = "�l:";
    private String typeTag = "�^�C�v:";
    private String indexTag = "����:";
    private String lengthTag = "�T�C�Y:";
    private String mapKeyTag = "MapKey:";
    private String mapValueTag = "MapValue:";
    private String indent = "      ";

    protected int row;

    public void write(PrintStream out, Object bean) throws XSerializeRuntimeException {
        if( bean == null ) {
            this.writeString(out, "null", 0);
            return;
        }
        if( _isDefaultType(bean.getClass()) ) {
            this.writeString(out, bean.toString(), 0);
            return;
        }

        //�����݊J�n
        try {
            this.row = 0;
            this._writeHeader(out, bean);
            this._write(out, bean, 1);
        } catch (IOException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        }
    }

    private void _writeHeader(PrintStream out, Object bean) throws XSerializeRuntimeException, IOException {
        this.writeString( out, this.getWriteType(bean.getClass(), null, 0), 0 );
    }

    private void _write(PrintStream out, Object bean, int column) throws XSerializeRuntimeException, IOException {
        PropertyUtilsBean utils = new PropertyUtilsBean();
        PropertyDescriptor[] propertyDescriptors = utils.getPropertyDescriptors(bean);
        for(PropertyDescriptor desc : propertyDescriptors) {
            //�Ή�����v���p�e�B�́A�ǂݏ����ł��鎖�B
            if( desc.getReadMethod() == null || desc.getWriteMethod() == null ) { continue; }

            Object value = null;
            try {
                value = PropertyUtils.getProperty(bean, desc.getName());
            } catch (IllegalAccessException e) {
                throw new XSerializeRuntimeException(e.getMessage());
            } catch (InvocationTargetException e) {
                throw new XSerializeRuntimeException(e.getMessage());
            } catch (NoSuchMethodException e) {
                throw new XSerializeRuntimeException(e.getMessage());
            }

            this.writeString( out, this.getWriteProperty(desc.getName(), column), column );
            this._writeValue(out, desc.getPropertyType(), value, column);
        }
    }

    private void _writeValue(PrintStream out, Class type, Object value, int depth) throws XSerializeRuntimeException, IOException {
        //����^�̏ꍇ
        if( this._isDefaultType(type) ) {
            this.writeString( out, this.getWriteType(type, value, depth+1), depth+1 );
            this.writeString( out, this.getWriteValue(value, depth+1), depth+1 );
        }else {//�I�u�W�F�N�g�̏ꍇ
            this.writeString( out, this.getWriteType(type, value, depth+1), depth+1 );
            if( value == null ) {
                this.writeString( out, this.getWriteValue(value, depth+1), depth+1 );
                return;
            }

            if( type.isArray() ) {
                //�z��̏ꍇ
                this._arrayWrite(out, value, depth+1);
            } else if( Collection.class.isAssignableFrom(type) ) {
                //�R���N�V�����̏ꍇ
                this._collectionWrite(out, value, depth+1);
            } else if( Map.class.isAssignableFrom(type) ) {
                //�}�b�v�̏ꍇ
                this._mapWrite(out, value, depth+1);
            } else {
                //�I�u�W�F�N�g�Ȃ̂ōċA
                this._write(out, value, depth+1);
            }
        }
    }

    private void _collectionWrite(PrintStream out, Object bean, int depth) throws XSerializeRuntimeException, IOException {
        Collection collection = (Collection)bean;
        Iterator itr = collection.iterator();

        long index=0;
        while( itr.hasNext() ) {
            Object item = itr.next();
            this.writeString( out, this.getIndexTag()+index, depth);
            if( item == null ) {
                this.writeString( out, "null", depth );
            }else {
                this._writeValue(out, item.getClass(), item, depth);
            }
            index++;
        }
    }

    private void _arrayWrite(PrintStream out, Object bean, int depth) throws XSerializeRuntimeException, IOException {
        Object[] array = (Object[])bean;

        long index=0;
        for(Object item : array) {
            this.writeString( out, this.getLengthTag()+array.length, depth );
            this.writeString( out, this.getIndexTag()+index, depth );
            if( item == null ) {
                this.writeString( out, "null", depth );
            }else {
                if( item.getClass().isArray() ) {
                    this._arrayWrite(out, item, depth);
                }else {
                    this._writeValue(out, item.getClass(), item, depth);
                }
            }
            index++;
        }
    }

    private void _mapWrite(PrintStream out, Object bean, int depth) throws XSerializeRuntimeException, IOException {
        Map map = (Map)bean;
        Iterator itr = map.keySet().iterator();

        while( itr.hasNext() ) {
            Object key = itr.next();

            //Key
            this.writeString( out, this.getMapKeyTag(), depth );
            if( key == null ) {
                this.writeString( out, "null", depth );
            }else {
                this._writeValue(out, key.getClass(), key, depth);
            }

            //Value
            this.writeString( out, this.getMapValueTag(), depth );
            Object value = map.get(key);
            if( value == null ) {
                this.writeString( out, "null", depth );
            }else {
                this._writeValue(out, value.getClass(), value, depth);
            }
        }
    }

    private String getDepthString(int depth) {
        String depthStr = "";
        for(int i=0; i<depth; i++) {
            depthStr += this.getIndent();
        }
        return depthStr;
    }

    private boolean _isDefaultType(Class type) throws XSerializeRuntimeException {
        if( type.isPrimitive() || String.class.isAssignableFrom(type) ||
            Number.class.isAssignableFrom(type) || Date.class.isAssignableFrom(type) ||
            Calendar.class.isAssignableFrom(type) || Character.class.isAssignableFrom(type) ||
            Boolean.class.isAssignableFrom(type) ) {
            return true;
        }
        return false;
    }

    private String getWriteProperty(String propertyName, int depth) throws XSerializeRuntimeException {
        return this.getPropertyTag()+propertyName;
    }

    private String getWriteType(Class type, Object value, int depth) throws XSerializeRuntimeException {
        if( value == null ) {
            return this.getTypeTag()+type.getCanonicalName();
        }else {
            return this.getTypeTag()+value.getClass().getCanonicalName();
        }
    }

    private String getWriteValue(Object value, int depth) throws XSerializeRuntimeException {
        String formatValue = "";
        if( value == null ) {
            return "null";
        }

        formatValue = this.formatValue(value);

        //���s�R�[�h�΍�
        formatValue = formatValue.replaceAll("\r\n", this.formatLineBreak("\r\n"));
        formatValue = formatValue.replaceAll("\n", this.formatLineBreak("\n"));

        return this.getValueTag()+formatValue;
    }

    protected void writeString(PrintStream out, String value, int column) throws XSerializeRuntimeException {
        out.println(this.getDepthString(column)+value);
        this.row++;
    }

    @SuppressWarnings("deprecation")
    protected String formatValue(Object value) throws XSerializeRuntimeException {
        String formatValue = value.toString();

        //Date/Calendar�̏����ϊ�
        if( value instanceof Date ) {
            formatValue = ((Date)value).toLocaleString();
        }else if( value instanceof Calendar ) {
            formatValue = ((Calendar)value).getTime().toLocaleString();
        }

        return formatValue;
    }

    protected String formatLineBreak(String srcSymbol) {
//        if( srcSymbol.equals("\r\n") || srcSymbol.equals("\n") ) {
//            return "%br%";
//        }
        return srcSymbol;
    }


    public String getIndexTag() {
        return indexTag;
    }


    public void setIndexTag(String indexTag) {
        this.indexTag = indexTag;
    }


    public String getLengthTag() {
        return lengthTag;
    }


    public void setLengthTag(String lengthTag) {
        this.lengthTag = lengthTag;
    }


    public String getPropertyTag() {
        return propertyTag;
    }


    public void setPropertyTag(String propertyTag) {
        this.propertyTag = propertyTag;
    }


    public String getTypeTag() {
        return typeTag;
    }


    public void setTypeTag(String typeTag) {
        this.typeTag = typeTag;
    }


    public String getValueTag() {
        return valueTag;
    }


    public void setValueTag(String valueTag) {
        this.valueTag = valueTag;
    }


    public String getMapKeyTag() {
        return mapKeyTag;
    }


    public void setMapKeyTag(String mapKeyTag) {
        this.mapKeyTag = mapKeyTag;
    }


    public String getMapValueTag() {
        return mapValueTag;
    }


    public void setMapValueTag(String mapValueTag) {
        this.mapValueTag = mapValueTag;
    }


    public String getIndent() {
        return indent;
    }


    public void setIndent(String indent) {
        this.indent = indent;
    }


}
