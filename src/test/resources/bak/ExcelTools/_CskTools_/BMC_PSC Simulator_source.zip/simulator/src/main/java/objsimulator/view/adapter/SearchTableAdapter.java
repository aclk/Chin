package objsimulator.view.adapter;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.DefaultTableModel;

import objsimulator.model.BeanAttribute;


public class SearchTableAdapter extends DefaultTableModel {
    private List<BeanAttribute> bean = new ArrayList<BeanAttribute>();
    private String[] columns = new String[] {"�N���X��","bean��"};

    public SearchTableAdapter(List<BeanAttribute> bean) {
        this.bean = bean;
    }

    public List<BeanAttribute> getBean() {
        return bean;
    }

    public void setBean(List<BeanAttribute> bean) {
        this.bean = bean;
    }

    public int getColumnCount() {
        return this.columns.length;
    }

    public String getColumnName(int column) {
        return this.columns[column];
    }

    public int getRowCount() {
        if( this.bean == null ) { return super.getRowCount(); }
        return this.bean.size();
    }

    public Object getValueAt(int row, int column) {
        if( this.bean == null ) { return super.getValueAt(row, column); }

        BeanAttribute beanAttr = this.bean.get(row);
        switch(column) {
            case 0: return beanAttr.getType();
            case 1: return beanAttr.getName();
            default: return null;
        }
    }

    public boolean isCellEditable(int row, int column) {
        return false;
    }


}
