package objsimulator.view;

import static objsimulator.constants.Constants.VERSION;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextPane;

import objsimulator.command.ExecCommand;
import objsimulator.command.TestFromFuncDefinition;
import objsimulator.exception.CommandRuntimeException;

public class SimulateWindow extends JFrame {

    private JTextPane scriptTxt;

    private JTextPane outputTxt;

    private JSplitPane splitPane;

    private JSplitPane splitPane2;

    private JSplitPane splitPane3;

    private SearchView searchView;

    private JMenuBar menubar;

    private JTextArea diTxt;

    private Font font = new Font("�l�r �S�V�b�N", Font.PLAIN, 14);

    public SimulateWindow() {
        this.setSize(640, 480);
        this.setTitle("BMC/PSC Simulator - version " + VERSION);

        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        this.getContentPane().setLayout(new BorderLayout());
        this.getSplitPane().setTopComponent(
            new JScrollPane(this.getScriptTxt()));
        this.getSplitPane().setBottomComponent(
            new JScrollPane(this.getOutputTxt()));

        this.getSplitPane3().setTopComponent(this.getSearchView());
        this.getSplitPane3().setBottomComponent(
            new JScrollPane(this.getDiTxt()));

        this.getSplitPane2().setLeftComponent(this.getSplitPane3());
        this.getSplitPane2().setRightComponent(this.getSplitPane());

        this.getContentPane().add(this.getSplitPane2(), BorderLayout.CENTER);
        this.setJMenuBar(this.getMenubar());
    }

    public JTextPane getOutputTxt() {
        if (this.outputTxt == null) {
            this.outputTxt = new JTextPane();
            this.outputTxt.setEditable(false);
            this.outputTxt.setFont(font);
            this.outputTxt.setBackground(new Color(240, 240, 240));
            this.outputTxt.setForeground(new Color(0, 0, 0));
        }
        return outputTxt;
    }

    public void setOutputTxt(JTextPane outputTxt) {
        this.outputTxt = outputTxt;
    }

    public JEditorPane getScriptTxt() {
        if (this.scriptTxt == null) {
            this.scriptTxt = new JTextPane();
            this.scriptTxt.addKeyListener(new KeyListener() {

                public void keyPressed(KeyEvent e) {
                }

                public void keyReleased(KeyEvent e) {
                    new Thread(new CodeHightlighter(
                        SimulateWindow.this.scriptTxt)).start();
                }

                public void keyTyped(KeyEvent e) {
                }
            });
            this.scriptTxt.setFont(font);
        }
        return scriptTxt;
    }

    public void setScriptTxt(JTextPane scriptTxt) {
        this.scriptTxt = scriptTxt;
    }

    public JSplitPane getSplitPane() {
        if (this.splitPane == null) {
            this.splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        }
        return splitPane;
    }

    public void setSplitPane(JSplitPane splitPane) {
        this.splitPane = splitPane;
    }

    public JSplitPane getSplitPane2() {
        if (this.splitPane2 == null) {
            this.splitPane2 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        }
        return splitPane2;
    }

    public void setSplitPane2(JSplitPane splitPane2) {
        this.splitPane2 = splitPane2;
    }

    public JMenuBar getMenubar() {
        if (this.menubar == null) {
            this.menubar = new JMenuBar();

            JMenu menu = new JMenu("�R�}���h");
            this.menubar.add(menu);

            menu.add(new JMenuItem("���s") {

                {
                    this.addActionListener(new ActionListener() {

                        public void actionPerformed(ActionEvent e) {
                            try {
                                new ExecCommand().execute(SimulateWindow.this);
                            } catch (CommandRuntimeException e1) {
                                new JOptionPane().showMessageDialog(
                                    SimulateWindow.this, e1.getMessage());
                            }
                        }
                    });
                }
            });

            menu.add(new JMenuItem("�@�\�݌v������e�X�g") {

                {
                    this.addActionListener(new ActionListener() {

                        public void actionPerformed(ActionEvent e) {
                            try {
                                new TestFromFuncDefinition()
                                    .execute(SimulateWindow.this);
                                new Thread(new CodeHightlighter(
                                    SimulateWindow.this.scriptTxt)).start();
                            } catch (CommandRuntimeException e1) {
                                new JOptionPane().showMessageDialog(
                                    SimulateWindow.this, e1.getMessage());
                            }
                        }
                    });
                }
            });
        }
        return menubar;
    }

    public void setMenubar(JMenuBar menuBar) {
        this.menubar = menuBar;
    }

    public JTextArea getDiTxt() {
        if (this.diTxt == null) {
            this.diTxt = new JTextArea();
        }
        return diTxt;
    }

    public void setDiTxt(JTextArea txt) {
        this.diTxt = txt;
    }

    public JSplitPane getSplitPane3() {
        if (this.splitPane3 == null) {
            this.splitPane3 = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        }
        return splitPane3;
    }

    public void setSplitPane3(JSplitPane splitPane3) {
        this.splitPane3 = splitPane3;
    }

    public SearchView getSearchView() {
        if (this.searchView == null) {
            this.searchView = new SearchView(this);
        }
        return searchView;
    }

    public void setSearchView(SearchView searchView) {
        this.searchView = searchView;
    }

    public void updateScript(String src) {
        this.getScriptTxt().setText(src);
        new Thread(new CodeHightlighter(SimulateWindow.this.scriptTxt)).start();
    }

}
