package objsimulator.constants;


public class Constants {

    public static final String VERSION = "0.0.4";

}
