package objsimulator.view;

import java.awt.Color;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.swing.JTextPane;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;


class CodeHightlighter implements Runnable {
    private JTextPane textPane;

    public CodeHightlighter(JTextPane textPane) {
        this.textPane = textPane;
    }

    public void run() {
        String text = this.textPane.getText();

        SimpleAttributeSet attrSet = new SimpleAttributeSet();
        boolean isComment=false;
        boolean isComment2=false;
        boolean isDblQuate=false;
        Color commentColor = new Color(63,127,95);
        Color stringColor = new Color(42,0,255);
        Color defaultColor = new Color(0,0,0);
        Color redColor = new Color(200,0,0);
        int offset=0;
        int cursor=0;

        Map<Integer, Integer> updateMap = new LinkedHashMap<Integer,Integer>();

        text = text.replaceAll("\r", "");
//        StyleConstants.setForeground(attrSet, defaultColor);
//        this.textPane.getStyledDocument().setCharacterAttributes(0, text.length(), attrSet, false);

        StyleConstants.setFontFamily(attrSet, this.textPane.getFont().getFamily());
        StyleConstants.setFontSize(attrSet, this.textPane.getFont().getSize());

        for(int i=0; i<text.length(); i++) {
            if( !isDblQuate && !isComment && !isComment2 && i+3 < text.length() && text.charAt(i+0) == 'n' && text.charAt(i+1) == 'e' && text.charAt(i+2) == 'w' && text.charAt(i+3) == ' ' ) {
                offset = i;
                updateMap.put(i, i+3);
                StyleConstants.setForeground(attrSet, redColor);
                this.textPane.getStyledDocument().setCharacterAttributes(offset, ((i+3)-offset), attrSet, true);

                i += 3;
            } else if( !isDblQuate && !isComment && !isComment2 && i+6 < text.length() && text.charAt(i+0) == 'r' && text.charAt(i+1) == 'e' && text.charAt(i+2) == 't' && text.charAt(i+3) == 'u' && text.charAt(i+4) == 'r' && text.charAt(i+5) == 'n' && text.charAt(i+6) == ' ' ) {
                offset = i;
                updateMap.put(i, i+6);
                StyleConstants.setForeground(attrSet, redColor);
                this.textPane.getStyledDocument().setCharacterAttributes(offset, ((i+6)-offset), attrSet, true);

                i += 6;
            } else if( !isDblQuate && !isComment && !isComment2 && i+1 < text.length() && text.charAt(i+0) == '/' && text.charAt(i+1) == '*' ) {
                cursor = i;

                isComment = true;
                offset = i;
                i++;
            } else if( !isDblQuate && isComment && !isComment2 && i+1 < text.length() && text.charAt(i+0) == '*' && text.charAt(i+1) == '/' ) {
                updateMap.put(cursor, i+1);

                isComment = false;
                StyleConstants.setForeground(attrSet, commentColor);
                this.textPane.getStyledDocument().setCharacterAttributes(offset, ((i+2)-offset), attrSet, true);
                i++;
            } else if( !isDblQuate && !isComment2 && !isComment && i+1 < text.length() && text.charAt(i+0) == '/' && text.charAt(i+1) == '/' ) {
                cursor = i;

                offset = i;
                isComment2 = true;
            } else if( !isDblQuate && isComment2 && !isComment && (text.charAt(i) == '\n' || i == text.length()-1) ){
                updateMap.put(cursor, i);

                isComment2 = false;
                StyleConstants.setForeground(attrSet, commentColor);
                this.textPane.getStyledDocument().setCharacterAttributes(offset, ((i+1)-offset), attrSet, true);
            } else if( !isComment && !isComment2 && text.charAt(i) == '"' ) {
                if( isDblQuate ) {
                    updateMap.put(cursor, i);

                    StyleConstants.setForeground(attrSet, stringColor);
                    this.textPane.getStyledDocument().setCharacterAttributes(offset, ((i+1)-offset), attrSet, true);
                }else {
                    offset = i;
                    cursor = i;
                }
                isDblQuate = !isDblQuate;
            }
        }

        StyleConstants.setForeground(attrSet, defaultColor);
        offset = 0;
        for(Integer begin : updateMap.keySet()) {
            this.textPane.getStyledDocument().setCharacterAttributes(offset, begin-offset, attrSet, true);
            offset = updateMap.get(begin)+1;
        }
        if( offset < text.length() ) {
            this.textPane.getStyledDocument().setCharacterAttributes(offset, text.length()-offset, attrSet, true);
        }

    }
}
