package objsimulator.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarInputStream;
import java.util.regex.Pattern;

import objsimulator.exception.ServiceRuntimeException;


public class ClassSearchService {
    public List<Class> findByName(String name) throws ServiceRuntimeException {
        String refPath = System.getProperty("sun.boot.class.path");
        refPath += ";"+System.getProperty("java.class.path");

        String[] classPathList = refPath.split(";");
        List<Class> results = new ArrayList<Class>();

        Pattern pattern = Pattern.compile(".*"+name+".*");
        for(String classPath : classPathList) {
            File file = new File(classPath);
            if( !file.exists() ) { continue; }

            this.findByName(file, true, null, pattern, results);
        }

        return results;
    }

    private void findByNameInJar(File jarFile, Pattern pattern, List<Class> results) throws ServiceRuntimeException {
        JarInputStream in;
        try {
            in = new JarInputStream(new FileInputStream(jarFile));
            JarEntry jarEntry = null;
            while( (jarEntry = in.getNextJarEntry()) != null ) {
                String fullPath = jarEntry.getName();
                if( !fullPath.endsWith(".class") ) { continue; }

                if( pattern.matcher(fullPath).find() ) {
                    String packageName = fullPath;
                    packageName = packageName.replaceAll("/", ".");
                    int index = fullPath.lastIndexOf("/");
                    if( index != -1 ) {
                        packageName = packageName.substring(0, index);
                    }

                    Class type;
                    try {
                        type = Class.forName(fullPath.replaceAll("/", "."));
                    } catch (ClassNotFoundException e) {
                        throw new ServiceRuntimeException(e.getMessage());
                    }
                    results.add(type);
                }
            }
            in.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new ServiceRuntimeException(e.getMessage());
        } catch (IOException e) {
            e.printStackTrace();
            throw new ServiceRuntimeException(e.getMessage());
        }
    }

    private void findByName(File file, boolean isRootDir, String packageName, Pattern pattern, List<Class> results) throws ServiceRuntimeException {
        if( file.isDirectory() ) {
            if( !isRootDir ) {
                if( packageName == null ) {
                    packageName = file.getName();
                }else {
                    packageName += "."+file.getName();
                }
            }

            for(File f : file.listFiles()) {
                this.findByName(f, false, packageName, pattern, results);
            }
        }else {
            if( file.getName().endsWith(".jar") ) {
                this.findByNameInJar(file, pattern, results);
            }else if( file.getName().endsWith(".class") ) {
                //����
                if( !pattern.matcher(file.getName()).find() ) {
                    return;
                }

                Class type;
                try {
                    type = Class.forName(file.getAbsolutePath().replaceAll("/", "."));
                } catch (ClassNotFoundException e) {
                    throw new ServiceRuntimeException(e.getMessage());
                }
                results.add(type);
            }
        }
    }

}
