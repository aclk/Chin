package objsimulator.service;

import java.io.StringWriter;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.util.Date;

import objsimulator.exception.ServiceRuntimeException;
import objsimulator.model.MethodAttribute;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;

public class SourceGenerateService {

    public String generate(MethodAttribute method)
        throws ServiceRuntimeException {
        String src = "";
        String temp = "";
        DateFormat formatter = DateFormat.getDateTimeInstance();

        VelocityContext context = new VelocityContext();

        temp =
            "/**\n* ${OBJECT}��${METHOD}�e�X�g\n* �e�X�g���{��:\n* �e�X�g�쐬����:${DATE}\n*/\n\n";

        context.put("OBJECT", method.getBean().getType());
        context.put("METHOD", method.getName());
        context.put("DATE", formatter.format(new Date()));

        StringWriter writer = new StringWriter();
        try {
            Velocity.evaluate(context, writer, "bmc_psc_simulator", temp);
        } catch (Exception e) {
            throw new ServiceRuntimeException(e.getMessage());
        }
        src += writer.toString();

        //��������
        if (method.getParameters().size() > 0) {
            for (int i = 0; i < method.getParameters().size(); i++) {
                String type = method.getParameters().get(i);

                src += "/**\n";
                src += "* ��" + (i + 1) + "�����̍쐬\n";
                src += "* �^:" + type + "\n";
                src += "*/\n";
                src += type + " arg" + (i + 1) + " = new " + type + "();\n";
                src += "\n";

                // ����VO�ɑ΂���setter����
                try {

                    Class cls = Class.forName(type);
                    Method[] methods = cls.getMethods();

                    for (Method voMethod : methods) {
                        if (voMethod.getName() != null
                            && voMethod.getName().substring(0, 3).equals("set")) {

                            src += "/**\n";
                            src +=
                                "* ����VO:" + voMethod.getName().substring(3)
                                    + "�̓���\n";
                            src +=
                                "* �^:"
                                    + voMethod.getParameterTypes()[0].getName()
                                    + "\n";
                            src += "*/\n";
                            src +=
                                "arg" + (i + 1) + "." + voMethod.getName()
                                    + "( �ҏW���ĉ����� );\n";
                            src += "\n";
                        }
                    }
                } catch (ClassNotFoundException cnfe) {
                    cnfe.printStackTrace();
                }
            }
        }

        //���\�b�h�̎��s
        String returnStr = "";
        if (method.getReturnType() != null
            && method.getReturnType().trim().length() != 0) {
            returnStr = "return ";
        }

        src += "/** \n";
        src += "* " + method.getName() + "���\�b�h�̎��s\n";
        src += "* �߂�l:" + method.getReturnType() + "\n";
        src += "*/\n";

        String methodName = method.getBean().getName().replaceAll("[$]", "_");

        src += returnStr + methodName + "." + method.getName() + "(";
        for (int i = 0; i < method.getParameters().size(); i++) {
            src += "arg" + (i + 1);
            if (i != method.getParameters().size() - 1) {
                src += ", ";
            }
        }
        src += ");\n";
        src += "\n";

        return src;
    }
}
