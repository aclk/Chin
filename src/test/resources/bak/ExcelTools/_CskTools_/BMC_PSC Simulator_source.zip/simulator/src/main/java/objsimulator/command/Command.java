package objsimulator.command;

import objsimulator.exception.CommandRuntimeException;


public interface Command {
    void execute(Object view) throws CommandRuntimeException;
}
