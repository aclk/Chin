package objsimulator;


public class Dependencies {

    public static void main(String[] args) {
        String allPath = System.getProperty("java.class.path");
        String[] pathList = allPath.split(";");
        for(String path : pathList) {
            if( !path.endsWith(".jar") ) { continue; }
            System.out.println(path);
        }
    }

}
