package objsimulator.serializer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.beanutils.BeanUtils;


public class TxtDeserializer implements XDeserializer {
    public Object read(InputStream in) throws XSerializeRuntimeException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));

        String line = null;
        Object bean = null;
        try {
            line = this.readLine(reader);
            if( line == null ) {
                throw new XSerializeRuntimeException("�擪�s�ɃI�u�W�F�N�g�̌^��񂪂���܂���B");
            }
            bean = this.newBean(line);

            for(;;) {
                line = this.readLine(reader);
                String propLine = this.getTagValue("Prop:", line);

                if( !this._readProperty(reader, bean, propLine) ) {
                    break;
                }
            }
        } catch (IOException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        }
        return bean;
    }

    private boolean _readProperty(BufferedReader reader, Object bean, String propertyLine) throws XSerializeRuntimeException, IOException {
        String line = null;
        line = reader.readLine();
        String typeStr = this.getTagValue("Type:", line);

        line = reader.readLine();
        String valueStr = this.getTagValue("Value:", line);
        Object value = null;

        boolean isNullTag = this.isNullTag(line);
        boolean isArray = typeStr.matches(".*\\[\\].*");


        if( isArray ) {
            //�z��Ȃ�
            String lengthStr = this.getTagValue("length:", line);
            int length = Integer.parseInt(lengthStr);

            typeStr = typeStr.replaceAll("\\[\\]", "");
            try {
                value = Array.newInstance(Class.forName(typeStr), length);
            } catch (ClassNotFoundException e) {
                throw new XSerializeRuntimeException(e.getMessage());
            }

            for(int i=0; i<length; i++) {
                line = reader.readLine();
                this._readProperty(reader, value, this.getTagValue("index:", line));
            }
        }else {
            if( valueStr == null && !isNullTag ) {
                if( propertyLine == null ) { throw new XSerializeRuntimeException("�s���ȍs�𔭌��B:"+line); }

                //�v���p�e�B�Ȃ̂ōċA
                value = this.newObject(typeStr);
                this._readProperty(reader, value, this.getTagValue("Prop:", line));
            }else {
                //�l�̎擾
                if( !isNullTag ) {
                    value = this.getValue(typeStr, valueStr);
                }
            }
        }

        //�Z�b�g�悪�z��Ȃ��
        if( bean.getClass().isArray() ) {
            int index = Integer.parseInt(propertyLine);
//            TestProperty p =(TestProperty)value;
            Array.set(bean, index, value);
        }else {
            //�v���p�e�B�̃Z�b�g
            try {
                BeanUtils.setProperty(bean, propertyLine, value);
            } catch (IllegalAccessException e) {
                throw new XSerializeRuntimeException(e.getMessage());
            } catch (InvocationTargetException e) {
                throw new XSerializeRuntimeException(e.getMessage());
            }
        }

        System.out.println("[P]"+propertyLine);
        System.out.println("[T]"+typeStr);
        System.out.println(valueStr);

        return true;
    }

    private Object getValue(String typeStr, String valueStr) throws XSerializeRuntimeException {
        Class type = null;
        try {
            type = Class.forName(typeStr);
        } catch (ClassNotFoundException e) {
            throw new XSerializeRuntimeException("�N���X��������܂���B:"+typeStr);
        }

        Object value = null;
        try {
            if( Number.class.isAssignableFrom(type) ) {
                value = type.getConstructor(new Class[]{String.class}).newInstance( valueStr );
            } else if( Date.class.isAssignableFrom(type) ) {
                value = type.getConstructor(new Class[]{String.class}).newInstance( valueStr );
            } else if( String.class.isAssignableFrom(type) ) {
                value = valueStr;
            } else if( Boolean.class.isAssignableFrom(type) ) {
                value = type.getConstructor(new Class[]{String.class}).newInstance( valueStr );
            } else if( Character.class.isAssignableFrom(type) ) {
                value = type.getConstructor(new Class[]{char.class}).newInstance( valueStr.toCharArray()[0] );
            } else if( Calendar.class.isAssignableFrom(type) ) {
                value = type.newInstance();
                BeanUtils.setProperty(value, "time", new Date(valueStr));
            }
        } catch (IllegalArgumentException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        } catch (SecurityException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        } catch (InstantiationException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        } catch (IllegalAccessException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        } catch (InvocationTargetException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        } catch (NoSuchMethodException e) {
            throw new XSerializeRuntimeException("�R���X�g���N�^��������܂���B");
        }

        return value;
    }

    protected Object newObject(String type) throws XSerializeRuntimeException {
        try {
            return Class.forName(type).newInstance();
        } catch (InstantiationException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        } catch (IllegalAccessException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        } catch (ClassNotFoundException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        }
    }

    protected Object newObject(Class type, String value) throws XSerializeRuntimeException {
        Object bean = null;
        try {
            if( Number.class.isAssignableFrom(type) ) {
                //���l
                bean = type.getConstructor(new Class[]{String.class}).newInstance( value );
            } else if( String.class.isAssignableFrom(type) ){
                //������
                bean = type.getConstructor(new Class[]{String.class}).newInstance( value );
            } else if( Character.class.isAssignableFrom(type) ){
                //����
                bean = type.getConstructor(new Class[]{char.class}).newInstance( value.charAt(0) );
            } else if( Boolean.class.isAssignableFrom(type) ){
                //�_��
                bean = type.getConstructor(new Class[]{String.class}).newInstance( value );
            } else if( Date.class.isAssignableFrom(type) ){
                //���t
                bean = type.getConstructor(new Class[]{String.class}).newInstance( value );
            } else if( Calendar.class.isAssignableFrom(type) ){
                //�J�����_�[
                bean = type.newInstance();
                BeanUtils.setProperty(bean, "time", new Date(value));
            }

            return bean;
        } catch (IllegalArgumentException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        } catch (SecurityException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        } catch (InstantiationException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        } catch (IllegalAccessException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        } catch (InvocationTargetException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        } catch (NoSuchMethodException e) {
            throw new XSerializeRuntimeException("�R���X�g���N�^��������܂���B");
        }
    }

    private Object newBean(String typeLine) throws XSerializeRuntimeException {
        String value = this.getTagValue("Type:", typeLine).trim();

        try {
            return Class.forName(value).newInstance();
        } catch (InstantiationException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        } catch (IllegalAccessException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        } catch (ClassNotFoundException e) {
            throw new XSerializeRuntimeException(e.getMessage());
        }
    }

    private String getTagValue(String tag, String line) throws XSerializeRuntimeException {
        String trimedLine = line.trim();

        if( !trimedLine.startsWith(tag) ) {
            return null;
        }

        int index = line.indexOf(tag);
        if( index == -1 ) {
            return null;
        }
        return line.substring(index+tag.length());
    }

    private boolean isNullTag(String line) throws XSerializeRuntimeException {
        return line.trim().startsWith("null");
    }

    protected String readLine(BufferedReader reader) throws IOException {
        return reader.readLine();
    }

}
