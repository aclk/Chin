package objsimulator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;


public class BootStrap {
    public BootStrap(String mainClassJar, String mainClass) {
        File dir = new File("./lib");
        if( !dir.isDirectory() ) {
            throw new RuntimeException("�u./lib/�v�f�B���N�g����������܂���B");
        }

        String libStr = mainClassJar+";";
        //libStr += this.searchJars(dir);

        String bootCmd = "@echo off\r\nSET CUR_DIR=%CD%\r\njava -Djava.ext.dirs=\"%CUR_DIR%\\lib\" -cp \"#LIBS#\" -Xms128m -Xmx1024m #MAINCLASS# %1 %2 %3 %4 %5 %6 %8 %9\r\n";
        bootCmd = bootCmd.replaceAll("#LIBS#", libStr);
        bootCmd = bootCmd.replaceAll("#MAINCLASS#", mainClass);

        File out = new File("boot.bat");
        try {
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(out), "MS932"));
            writer.write(bootCmd);
            writer.flush();
            writer.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private String searchJars(File dir) {
        String libStr = "";
        for(int i=0; i<dir.listFiles().length; i++) {
            File file = dir.listFiles()[i];
            if( file.isDirectory() ) {
                libStr += this.searchJars(file);
                continue;
            }
            if( !file.getAbsolutePath().endsWith(".jar") ) {
                continue;
            }

            libStr += "./lib/"+file.getName();
            if( i != dir.listFiles().length-1 ) {
                libStr += ";";
            }
        }

        return libStr;
    }

    public static void main(String[] args) {
        new BootStrap(args[0], args[1]);
    }
}
