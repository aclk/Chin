package objsimulator.serializer;

import java.io.InputStream;


public interface XDeserializer {
    Object read(InputStream in) throws XSerializeRuntimeException;
}
