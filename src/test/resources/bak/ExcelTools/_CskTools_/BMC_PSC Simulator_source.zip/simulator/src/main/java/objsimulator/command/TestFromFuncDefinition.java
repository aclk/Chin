package objsimulator.command;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.util.Date;

import javax.swing.JFileChooser;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.read.biff.BiffException;
import objsimulator.exception.CommandRuntimeException;
import objsimulator.view.SimulateWindow;
import objsimulator.view.filter.ExcelFilter;

public class TestFromFuncDefinition implements Command {

    private String methodNameJp;

    private String methodNameEn;

    private String classNameJp;

    private String classNameEn;

    private String packageName;

    private String resourceType;

    private String category;

    private String parameterVoJp;

    private String parameterVoEn;

    private String parameterJp;

    private String parameterEn;

    private String returnValueVoJp;

    private String returnValueVoEn;

    private String returnValueJp;

    private String returnValueEn;

    private String exceptionClass;

    private String remarks;

    public void execute(Object view) throws CommandRuntimeException {
        SimulateWindow window = (SimulateWindow)view;

        File currentPath = null;
        FileInputStream fis = null;
        InputStreamReader ir = null;
        BufferedReader br = null;
        try {
            fis = new FileInputStream("tmp\\.path");
            ir = new InputStreamReader(fis, "MS932");
            br = new BufferedReader(ir);
            String path = br.readLine();
            currentPath = new File(path);
        } catch (Exception e) {
            // NOP
        } finally {
            try {
                br.close();
                ir.close();
                fis.close();
            } catch (Exception e) {
                // NOP
            }
        }

        JFileChooser fileChooser = null;
        if (currentPath != null) {
            fileChooser = new JFileChooser(currentPath);
        } else {
            fileChooser = new JFileChooser();
        }
        fileChooser.setFileFilter(new ExcelFilter());
        if (fileChooser.showOpenDialog(window) != JFileChooser.APPROVE_OPTION) {
            return;
        }

        File file = fileChooser.getSelectedFile();

        FileOutputStream fos = null;
        OutputStreamWriter osw = null;
        BufferedWriter bw = null;
        try {
            fos = new FileOutputStream("tmp\\.path");
            osw = new OutputStreamWriter(fos, "MS932");
            bw = new BufferedWriter(osw);
            bw.write(file.getParent());
        } catch (Exception e) {
            // NOP
        } finally {
            try {
                bw.close();
                osw.close();
                fos.close();
            } catch (IOException e) {
                // NOP
            }
        }

        Workbook workbook = null;
        WorkbookSettings settings = new WorkbookSettings();
        settings.setGCDisabled(true);
        try {
            workbook =
                Workbook.getWorkbook(new FileInputStream(file), settings);
            Sheet sheet = workbook.getSheet("�@�\�T�v");
            if (sheet == null) {
                throw new CommandRuntimeException("�u�@�\�T�v�v�V�[�g��������܂���B");
            }

            this.methodNameJp = sheet.getCell(2, 1).getContents();
            this.methodNameEn = sheet.getCell(2, 2).getContents();
            this.classNameJp = sheet.getCell(2, 3).getContents();
            this.classNameEn = sheet.getCell(2, 4).getContents();
            this.packageName = sheet.getCell(2, 5).getContents();
            this.resourceType = sheet.getCell(2, 6).getContents();
            this.category = sheet.getCell(2, 7).getContents();
            this.parameterVoJp = sheet.getCell(2, 8).getContents();
            this.parameterVoEn = sheet.getCell(2, 9).getContents();
            this.parameterJp = sheet.getCell(2, 10).getContents();
            this.parameterEn = sheet.getCell(2, 11).getContents();
            this.returnValueVoJp = sheet.getCell(2, 12).getContents();
            this.returnValueVoEn = sheet.getCell(2, 13).getContents();
            this.returnValueJp = sheet.getCell(2, 14).getContents();
            this.returnValueEn = sheet.getCell(2, 15).getContents();
            this.exceptionClass = sheet.getCell(2, 16).getContents();
            this.remarks = sheet.getCell(2, 17).getContents();
            workbook.close();

            String src = "";
            String temp = "";
            String beanId =
                Character.toLowerCase(this.classNameEn.charAt(0))
                    + this.classNameEn.substring(1);
            window.getDiTxt().setText(
                this.packageName + "." + this.classNameEn + " " + beanId);
            DateFormat formatter = DateFormat.getDateTimeInstance();

            temp =
                "/**\n* #OBJECT#��#METHOD#�e�X�g\n* �e�X�g���{��:\n* �e�X�g�쐬����:#DATE#\n*/\n\n";
            temp = temp.replaceAll("#OBJECT#", this.classNameJp);
            temp = temp.replaceAll("#METHOD#", this.methodNameJp);
            temp = temp.replaceAll("#DATE#", formatter.format(new Date()));
            src += temp;

            //InputVO�i����VO������ꍇ�j
            if (parameterVoEn != null && parameterVoEn.trim().length() > 0) {
                src += "/**\n";
                src += "* " + this.parameterVoJp + "�̍쐬(����VO)\n";
                src += "*/\n";
                src +=
                    this.packageName + ".vo." + this.parameterVoEn
                        + " paramVO = new " + this.packageName + ".vo."
                        + this.parameterVoEn + "();\n";
                src += "\n";

                String[] paramsEn = this.parameterEn.split(",");
                String[] paramsJp = this.parameterJp.split(",");
                for (int i = 0; i < paramsEn.length; i++) {
                    String paramEn = paramsEn[i].trim();
                    String paramJp = paramsJp[i].trim();

                    src += "/** \n";
                    src +=
                        "* ����VO:" + paramEn.split(" ")[1] + "("
                            + paramJp.split(" ")[1] + ")�̓���\n";
                    src += "* �^:" + paramEn.split(" ")[0] + "\n";
                    src += "*/\n";
                    src +=
                        "paramVO.set"
                            + Character.toUpperCase(paramEn.split(" ")[1]
                                .toCharArray()[0])
                            + paramEn.split(" ")[1].substring(1)
                            + "( �ҏW���ĉ����� );\n";
                    src += "\n";
                }

                //���\�b�h
                String className =
                    Character.toLowerCase(this.classNameEn.charAt(0))
                        + this.classNameEn.substring(1);
                src += "/** \n";
                src += "* " + this.methodNameJp + "���\�b�h�̎��s\n";
                src += "*/\n";
                src +=
                    "return " + className + "." + this.methodNameEn
                        + "( paramVO );";
                src += "\n";
            } else if (this.parameterEn != null
                && this.parameterEn.trim().length() > 0) {//���ʂ̈�����K�v�Ƃ���B
                String[] paramsEn = this.parameterEn.split(",");
                String[] paramsJp = this.parameterJp.split(",");
                String params = "";
                for (int i = 0; i < paramsEn.length; i++) {
                    String paramEn = paramsEn[i].trim();
                    String paramJp = paramsJp[i].trim();

                    src += "/** \n";
                    src +=
                        "* ����:" + paramEn.split(" ")[1] + "("
                            + paramJp.split(" ")[1] + ")�̒�`\n";
                    src += "* �^:" + paramEn.split(" ")[0] + "\n";
                    src += "*/\n";
                    src += "�ҏW���ĉ������B\n";
                    src += "\n";

                    params += paramEn.split(" ")[1];
                    if (i != paramsEn.length - 1) {
                        params += ", ";
                    }
                }

                //���\�b�h
                String className =
                    Character.toLowerCase(this.classNameEn.charAt(0))
                        + this.classNameEn.substring(1);
                src += "/** \n";
                src += "* " + this.methodNameJp + "���\�b�h�̎��s\n";
                src += "*/\n";
                src +=
                    "return " + className + "." + this.methodNameEn + "( "
                        + params + " );";
                src += "\n";

            } else {//�����͂Ȃ�
                //���\�b�h
                String className =
                    Character.toLowerCase(this.classNameEn.charAt(0))
                        + this.classNameEn.substring(1);
                src += "/** \n";
                src += "* " + this.methodNameJp + "���\�b�h�̎��s\n";
                src += "*/\n";
                src += "return " + className + "." + this.methodNameEn + "();";
                src += "\n";
            }

            window.getScriptTxt().setText(src);
        } catch (FileNotFoundException e) {
            throw new CommandRuntimeException(e.getMessage());
        } catch (IOException e) {
            throw new CommandRuntimeException(e.getMessage());
        } catch (BiffException e) {
            throw new CommandRuntimeException(e.getMessage());
        }
    }
}
