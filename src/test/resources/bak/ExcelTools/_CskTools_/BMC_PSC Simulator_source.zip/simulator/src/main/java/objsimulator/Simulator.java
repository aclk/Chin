package objsimulator;

import static objsimulator.constants.Constants.VERSION;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import objsimulator.exception.ServiceRuntimeException;
import objsimulator.service.SimulateService;

public class Simulator {

    public static void main(String[] args) {
        System.out.println("-----------------------------------------------");
        System.out.println("               BMC/PSC Simulator               ");
        System.out.println("                 version " + VERSION
            + "                 ");
        System.out.println("-----------------------------------------------");

        System.out.println("-file \"�X�N���v�g�t�@�C���p�X\"");
        System.out.println("-src \"�X�N���v�g �i�� -file �w�莞�͕s�v �j\"");
        System.out.println("-di \"DI�w�� �����́u�C���^�[�t�F�[�X�� beanId�v�i�J���}��؂�ŕ����w��j\"");

        //�����̎擾
        Map<String, String> paramaterMap = new HashMap<String, String>();
        for (int i = 0; i < args.length; i += 2) {
            paramaterMap.put(args[i], args[i + 1]);
        }
        if (!paramaterMap.containsKey("-file")
            && !paramaterMap.containsKey("-src")) {
            System.out.println("-file�A-src�̂����ꂩ�̎w�肪����܂���B");
            return;
        }
        if (!paramaterMap.containsKey("-di")) {
            System.out.println("-di �w�肪����܂���B");
            return;
        }

        //�e�X�g�ΏۃN���X�̎擾
        String[] di = paramaterMap.get("-di").split("[,]");

        //�X�N���v�g�̎擾
        String src = "";
        if (paramaterMap.containsKey("-file")) {
            File file = new File(paramaterMap.get("-file"));
            try {
                BufferedReader reader =
                    new BufferedReader(new InputStreamReader(
                        new FileInputStream(file)));
                String line;
                while ((line = reader.readLine()) != null) {
                    src += line + "\n";
                }
                reader.close();
            } catch (FileNotFoundException e1) {
                System.out.println("�t�@�C���I�[�v���Ɏ��s�B:" + file.getAbsolutePath());
                return;
            } catch (IOException e) {
                System.out.println("�t�@�C���ǂݍ��ݒ��ɗ�O:" + file.getAbsolutePath());
                return;
            }
        } else {
            src = paramaterMap.get("-src");
        }

        //�f�o�b�O
        SimulateService service = null;
        try {
            service = new SimulateService();
            if (paramaterMap.containsKey("-debug")
                && paramaterMap.get("-debug").equals("true")) {
                System.out.println(service.buildScript(di, src));
            }
        } catch (ServiceRuntimeException e) {
            System.out.println(e.getMessage());
            return;
        }

        //���s
        try {
            service.invokeMethodAndDisplayReturnValue(di, src);
        } catch (ServiceRuntimeException e) {
            System.out.println(e.getMessage());
            return;
        }
    }
}
