package objsimulator.test;

import java.io.StringWriter;

import junit.framework.TestCase;

import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;


public class VelocityTest extends TestCase {
    public void testRun() throws Exception {
        Velocity.init();
        VelocityContext velocityContext = new VelocityContext();
        velocityContext.put("hello", "����ɂ���");

        StringWriter writer = new StringWriter();
        Velocity.evaluate(velocityContext, writer, "test", "${hello}");
        assertEquals(writer.toString(), "����ɂ���");
    }
}
