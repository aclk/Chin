package objsimulator;

import objsimulator.view.SimulateWindow;


public class SimulateEditor {
    public static void main(String[] args) {
        new GenericBootStrap(new String[]{"./simulator.jar","objsimulator.service.BeanSearchService"});

        SimulateWindow window = new SimulateWindow();
        window.getSplitPane().setDividerLocation(window.getHeight()/2);
        window.setVisible(true);

        window.getSplitPane().setDividerLocation(window.getHeight()-window.getHeight()/3);
        window.getSplitPane2().setDividerLocation(window.getWidth()/5);
        window.getSplitPane3().setDividerLocation(window.getHeight()/2);
        window.getSearchView().getSplitPane().setDividerLocation(window.getHeight()/4);
    }
}
