package objsimulator.view;

import java.awt.BorderLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import objsimulator.exception.ServiceRuntimeException;
import objsimulator.model.BeanAttribute;
import objsimulator.model.MethodAttribute;
import objsimulator.service.SourceGenerateService;
import objsimulator.view.adapter.MethodTableAdapter;

import org.apache.commons.beanutils.PropertyUtilsBean;

public class MethodView extends JPanel {

    private JTable methodTable;

    private SearchView parent;

    public MethodView(SearchView parent) {
        this.parent = parent;
        this.setLayout(new BorderLayout());

        this.add(new JScrollPane(this.getMethodTable()), BorderLayout.CENTER);

        this.getMethodTable().addMouseListener(new MouseListener() {

            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() >= 2
                    && e.getButton() == MouseEvent.BUTTON1) {
                    if (methodTable.getSelectedRow() != -1
                        && methodTable.getModel() instanceof MethodTableAdapter) {
                        MethodTableAdapter adapter =
                            (MethodTableAdapter)methodTable.getModel();
                        MethodAttribute methodAttr =
                            adapter.getBean().get(methodTable.getSelectedRow());
                        try {
                            if (methodAttr.getBean().getName() != null) {
                                String src =
                                    new SourceGenerateService()
                                        .generate(methodAttr);
                                MethodView.this.parent.parent.updateScript(src);
                            }
                        } catch (ServiceRuntimeException e1) {
                            JOptionPane.showMessageDialog(MethodView.this, e1
                                .getMessage());
                        }
                    }
                }
            }

            public void mouseEntered(MouseEvent e) {
            }

            public void mouseExited(MouseEvent e) {
            }

            public void mousePressed(MouseEvent e) {
            }

            public void mouseReleased(MouseEvent e) {
            }
        });
    }

    public JTable getMethodTable() {
        if (this.methodTable == null) {
            this.methodTable = new JTable();
            this.methodTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        }
        return methodTable;
    }

    public void setMethodTable(JTable methodTable) {
        this.methodTable = methodTable;
    }

    public void updateMethodView(BeanAttribute beanAttr) {
        List<Method> methods = new ArrayList<Method>();

        try {
            Class type = Class.forName(beanAttr.getType());
            for (PropertyDescriptor desc : new PropertyUtilsBean()
                .getPropertyDescriptors(type)) {
                if (desc.getReadMethod() != null) {
                    methods.add(desc.getReadMethod());
                }
                if (desc.getWriteMethod() != null) {
                    methods.add(desc.getWriteMethod());
                }
            }
            for (Method m : type.getMethods()) {
                if (!methods.contains(m)) {
                    methods.add(m);
                }
            }

            List<MethodAttribute> methodAttrs =
                new ArrayList<MethodAttribute>();
            for (Method m : methods) {
                MethodAttribute methodAttr = new MethodAttribute();
                methodAttr.setName(m.getName());
                methodAttr.setReturnType(m.getReturnType().getCanonicalName());
                methodAttr.setBean(beanAttr);

                for (int i = 0; i < m.getParameterTypes().length; i++) {
                    Class t = m.getParameterTypes()[i];
                    methodAttr.getParameters().add(t.getCanonicalName());
                }
                methodAttrs.add(methodAttr);
            }

            MethodTableAdapter adapter = new MethodTableAdapter(methodAttrs);
            this.methodTable.setModel(adapter);

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

}
