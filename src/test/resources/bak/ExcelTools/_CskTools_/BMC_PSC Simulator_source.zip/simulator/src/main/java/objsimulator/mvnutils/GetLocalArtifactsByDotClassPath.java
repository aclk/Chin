package objsimulator.mvnutils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.commons.io.FileUtils;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class GetLocalArtifactsByDotClassPath {
    public GetLocalArtifactsByDotClassPath(String[] args) throws Throwable {
        File destDir = new File(args[0]);
        String mvnHome = args[1].replaceAll("\\\\", "/");
        File classpathFile = new File(args[2]);

        //lib�N���A
        MvnUtilFacade mvn = new MvnUtilFacade();
        mvn.clean(destDir);

        //.classpath�̓Ǎ���
        SAXParserFactory spfactory = SAXParserFactory.newInstance();
        SAXParser parser = spfactory.newSAXParser();

        XmlParser xmlParser = new XmlParser();
        parser.parse(classpathFile, xmlParser);

        //lib�փR�s�[
        for(String path : xmlParser.getJars()) {
            File file = new File(path.replaceFirst("M2_REPO", mvnHome));
            FileUtils.copyFileToDirectory(file, destDir);
            System.out.println(file.getName());
        }
    }

    public static void main(String[] args) throws Throwable {
        new GetLocalArtifactsByDotClassPath(args);
    }

    private class XmlParser extends DefaultHandler {
        private List<String> jars = new ArrayList<String>();

        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
            if( qName.equals("classpathentry") && attributes.getValue("kind").equals("var") ) {
                jars.add( attributes.getValue("path") );
            }
        }

        public List<String> getJars() {
            return jars;
        }
    }
}
