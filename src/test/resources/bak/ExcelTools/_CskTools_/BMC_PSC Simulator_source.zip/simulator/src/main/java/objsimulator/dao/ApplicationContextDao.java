package objsimulator.dao;

import java.io.File;
import java.util.List;

import objsimulator.exception.DaoRuntimeException;
import objsimulator.model.BeanAttribute;


public interface ApplicationContextDao {
    void dumpToXML(File file) throws DaoRuntimeException;
    void initializeByXML(File file) throws DaoRuntimeException;
    List<BeanAttribute> findByName(String name) throws DaoRuntimeException;
}
