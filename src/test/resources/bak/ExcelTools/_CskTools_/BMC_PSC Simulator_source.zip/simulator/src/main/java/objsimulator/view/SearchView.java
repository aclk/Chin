package objsimulator.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import objsimulator.exception.ServiceRuntimeException;
import objsimulator.model.BeanAttribute;
import objsimulator.service.BeanSearchService;
import objsimulator.view.adapter.SearchTableAdapter;

public class SearchView extends JPanel {

    private JTextField keywordTxt;

    private JTable resultTable;

    private JButton addBtn;

    public SimulateWindow parent;

    private MethodView methodView;

    private JSplitPane splitPane;

    public SearchView(SimulateWindow window) {
        this.parent = window;

        this.setLayout(new BorderLayout());

        this.add(this.getKeywordTxt(), BorderLayout.NORTH);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(new JScrollPane(this.getResultTable()), BorderLayout.CENTER);

        this.getSplitPane().setTopComponent(panel);
        this.getSplitPane().setBottomComponent(this.getMethodView());

        this.add(this.getSplitPane(), BorderLayout.CENTER);

        this.getKeywordTxt().addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                try {
                    List<BeanAttribute> results =
                        new BeanSearchService().findByName(keywordTxt.getText()
                            .trim());
                    SearchTableAdapter adapter =
                        new SearchTableAdapter(results);
                    resultTable.setModel(adapter);
                } catch (ServiceRuntimeException e1) {
                    JOptionPane.showMessageDialog(SearchView.this, e1
                        .getMessage());
                }
            }
        });

        this.getResultTable().addMouseListener(new MouseListener() {

            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() >= 2
                    && e.getButton() == MouseEvent.BUTTON1) {
                    if (resultTable.getSelectedRow() != -1
                        && resultTable.getModel() instanceof SearchTableAdapter) {
                        SearchTableAdapter adapter =
                            (SearchTableAdapter)resultTable.getModel();
                        BeanAttribute attr =
                            adapter.getBean().get(resultTable.getSelectedRow());

                        String old =
                            SearchView.this.parent.getDiTxt().getText().trim();
                        if (old.length() != 0) {
                            old += "\n";
                        }

                        if (JOptionPane.showConfirmDialog(SearchView.this, attr
                            .getName()
                            + "��DI�̑ΏۂɊ܂߂܂��B ��낵���ł��傤���H", "���b�Z�[�W",
                            JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                            SearchView.this.parent.getDiTxt().setText(
                                old + attr.getType() + " " + attr.getName()
                                    + "\n");
                        }
                    }
                }
                if (e.getButton() == MouseEvent.BUTTON1) {
                    if (resultTable.getSelectedRow() != -1
                        && resultTable.getModel() instanceof SearchTableAdapter) {
                        SearchTableAdapter adapter =
                            (SearchTableAdapter)resultTable.getModel();
                        BeanAttribute attr =
                            adapter.getBean().get(resultTable.getSelectedRow());
                        SearchView.this.methodView.updateMethodView(attr);
                    }
                }
            }

            public void mouseEntered(MouseEvent e) {
            }

            public void mouseExited(MouseEvent e) {
            }

            public void mousePressed(MouseEvent e) {
            }

            public void mouseReleased(MouseEvent e) {
            }
        });
    }

    public JButton getAddBtn() {
        if (this.addBtn == null) {
            this.addBtn = new JButton("�ǉ�");
        }
        return addBtn;
    }

    public void setAddBtn(JButton addBtn) {
        this.addBtn = addBtn;
    }

    public JTextField getKeywordTxt() {
        if (this.keywordTxt == null) {
            this.keywordTxt = new JTextField();
            this.keywordTxt.setPreferredSize(new Dimension(0, 20));
        }
        return keywordTxt;
    }

    public void setKeywordTxt(JTextField keywordTxt) {
        this.keywordTxt = keywordTxt;
    }

    public JTable getResultTable() {
        if (this.resultTable == null) {
            this.resultTable = new JTable();
        }
        return resultTable;
    }

    public void setResultTable(JTable resultTable) {
        this.resultTable = resultTable;
    }

    public MethodView getMethodView() {
        if (this.methodView == null) {
            this.methodView = new MethodView(this);
            this.methodView.setPreferredSize(new Dimension(20, 200));
        }
        return methodView;
    }

    public void setMethodView(MethodView methodView) {
        this.methodView = methodView;
    }

    public JSplitPane getSplitPane() {
        if (this.splitPane == null) {
            this.splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        }
        return splitPane;
    }

    public void setSplitPane(JSplitPane splitPane) {
        this.splitPane = splitPane;
    }

}
