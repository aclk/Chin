package objsimulator.mvnutils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;


public class MvnUtilFacade {
    public List<Pom> getDependencies(File pomFile, File mavenHomeDir) throws MvnUtilFacadeRuntimeException {
        PomReader reader = new PomReaderImpl();
        try {
            Pom pom = reader.read(pomFile, mavenHomeDir);
            Map<String, Pom> dependencies = new HashMap<String, Pom>();
            this.collectDependencies(pom, dependencies);

            return new ArrayList<Pom>(dependencies.values());
        } catch (PomReaderRuntimeException e) {
            throw new MvnUtilFacadeRuntimeException(e.getMessage());
        }
    }

    private void collectDependencies(Pom pom, Map<String, Pom> dependencies) {
        Pom existPom = dependencies.get(pom.getArtifactId());

        if( (existPom == null || existPom.getVersion().compareToIgnoreCase(pom.getVersion()) < 0) && pom.getJarPath() != null ) {
            if( pom.getVersion() != null && pom.getVersion().trim().length() > 0 ) {
                dependencies.put(pom.getArtifactId(), pom);
            }
        }

        if( pom.getParent() != null ) {
            this.collectDependencies(pom.getParent(), dependencies);
        }

        for(Pom depPom : pom.getDependencies()) {
            this.collectDependencies(depPom, dependencies);
        }
    }

    public void copyArtifacts(File pomFile, File mavenHomeDir, File destDir) throws MvnUtilFacadeRuntimeException {
        List<Pom> dependencies = this.getDependencies(pomFile, mavenHomeDir);
        for(Pom pom : dependencies) {
            try {
                FileUtils.copyFileToDirectory(new File(pom.getJarPath()), destDir);
            } catch (IOException e) {
                throw new MvnUtilFacadeRuntimeException(e.getMessage());
            }
        }
    }

    public void clean(File destDir) throws MvnUtilFacadeRuntimeException {
        try {
            FileUtils.cleanDirectory(destDir);
        } catch (IOException e) {
            throw new MvnUtilFacadeRuntimeException(e.getMessage());
        }
    }
}
