﻿Option Explicit On
Option Compare Text
Option Strict Off
Imports XL = Microsoft.Office.Interop.Excel
Imports OFC = Microsoft.Office.Interop
Imports System
Imports System.Runtime.InteropServices
Imports WIN32 = Microsoft.Win32

<ClassInterface(ClassInterfaceType.AutoDual), ComVisible(True)> _
Public Class ExcelMultiplication

    Public Function MultiplyBy2(ByVal D As Double) As Double
        Return D * 2
    End Function

    Public Function MultiplyBy4(ByVal D As Double) As Double
        Return D * 4
    End Function


    <ComRegisterFunctionAttribute()> _
 Public Shared Sub RegisterFunction(ByVal type As Type)
        WIN32.Registry.ClassesRoot.CreateSubKey(GetSubkeyName(type))
    End Sub

    <ComUnregisterFunctionAttribute()> _
Public Shared Sub UnregisterFunction(ByVal type As Type)
        WIN32.Registry.ClassesRoot.DeleteSubKey(GetSubkeyName(type), False)
    End Sub

    Private Shared Function GetSubkeyName(ByVal type As Type) As String
        Dim S As New System.Text.StringBuilder()
        S.Append("CLSID\{")
        S.Append(type.GUID.ToString().ToUpper())
        S.Append("}\Programmable")
        Return S.ToString()
    End Function

End Class